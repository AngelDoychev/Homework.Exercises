package com.example.jsonprocessing.services.impl;

import com.example.jsonprocessing.constants.GlobalConstants;
import com.example.jsonprocessing.model.dto.CategorySeedDto;
import com.example.jsonprocessing.model.dto.UserSeedDto;
import com.example.jsonprocessing.model.entities.Category;
import com.example.jsonprocessing.model.entities.User;
import com.example.jsonprocessing.repositories.UserRepository;
import com.example.jsonprocessing.services.UserService;
import com.example.jsonprocessing.util.ValidationUtil;
import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

@Service
public class UserServiceImpl implements UserService {
    private static final String FILE_NAME = "users.json";
    private final UserRepository userRepository;
    private final ValidationUtil validationUtil;
    private final Gson gson;
    private final ModelMapper modelMapper;

    public UserServiceImpl(UserRepository userRepository, ValidationUtil validationUtil, Gson gson, ModelMapper modelMapper) {
        this.userRepository = userRepository;
        this.validationUtil = validationUtil;
        this.gson = gson;
        this.modelMapper = modelMapper;
    }

    @Override
    public void seedDataFromJson() throws IOException {
        if (this.userRepository.count() > 0) {
            return;
        }
        String jsonFile = Files.readString(Path.of(GlobalConstants.JSON_FILE_PATH + FILE_NAME));
        UserSeedDto[] userSeedDtos = this.gson.fromJson(jsonFile, UserSeedDto[].class);
        Arrays.stream(userSeedDtos)
                .filter(this.validationUtil::isValid)
                .map(user -> this.modelMapper.map(user, User.class))
                .forEach(this.userRepository::save);
    }
}
