package com.example.jsonprocessing.util;

public interface ValidationUtil {
    <E> boolean isValid(E entity);
}
