package com.example.jsonprocessing.services;

import com.example.jsonprocessing.model.entities.Category;

import java.io.IOException;

public interface CategoryService {
    void seedDataFromJson() throws IOException;
    long count();
    Category getRandomCategory();
}
