package com.example.jsonprocessing;

import com.example.jsonprocessing.model.dto.ProductPrintNamePriceAndSellerDto;
import com.example.jsonprocessing.model.entities.Product;
import com.example.jsonprocessing.services.CategoryService;
import com.example.jsonprocessing.services.ProductService;
import com.example.jsonprocessing.services.UserService;
import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

@Component
public class CommandLineRunnerImpl implements CommandLineRunner {
    private final Scanner scanner;
    private final CategoryService categoryService;
    private final ProductService productService;
    private final UserService userService;
    private final Gson gson;
    private final ModelMapper modelMapper;

    public CommandLineRunnerImpl(CategoryService categoryService, ProductService productService, UserService userService, Gson gson, ModelMapper modelMapper) {
        this.categoryService = categoryService;
        this.productService = productService;
        this.userService = userService;
        this.gson = gson;
        this.modelMapper = modelMapper;
        scanner = new Scanner(System.in);
    }

    @Override
    public void run(String... args) throws Exception {
        seedData();
        System.out.println("Please select exercise number!");
        int exerciseNumber = Integer.parseInt(this.scanner.nextLine());
        switch (exerciseNumber) {
            case 1 -> exercise1();
            case 2 -> exercise2();
        }
    }

    private void exercise2() {

    }

    private void exercise1() throws IOException {
        List<Product> products = this.productService.findAllByPriceBetweenAndBuyerIsNullOrderByPrice(new BigDecimal("500"), new BigDecimal("1000"));

         List<ProductPrintNamePriceAndSellerDto> productsDto = products
                .stream()
                .map(product -> {
                    ProductPrintNamePriceAndSellerDto productDto = this.modelMapper.map(product, ProductPrintNamePriceAndSellerDto.class);
                    productDto.setSeller(String.format("%s %s",
                            product.getSeller().getFirstName(),
                            product.getSeller().getLastName()));
                    return productDto;
                })

                .collect(Collectors.toList());

         String productJson = this.gson.toJson(productsDto);
         Files.write(Path.of("src/main/resources/files/jsonTargetFile/ex1.json"), Collections.singleton(productJson));
    }

    private void seedData() throws IOException {
        this.categoryService.seedDataFromJson();
        this.userService.seedDataFromJson();
        this.productService.seedDataFromJson();
    }
}
