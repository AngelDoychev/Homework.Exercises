package com.example.jsonprocessing.services;

import java.io.IOException;

public interface UserService {
    void seedDataFromJson() throws IOException;
}
