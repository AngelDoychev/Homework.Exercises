package com.example.jsonprocessing.constants;

public class GlobalConstants {
    public static final String JSON_FILE_PATH = "src/main/resources/files/";
}
