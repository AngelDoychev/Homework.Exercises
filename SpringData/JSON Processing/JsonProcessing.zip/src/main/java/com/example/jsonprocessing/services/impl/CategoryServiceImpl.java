package com.example.jsonprocessing.services.impl;

import com.example.jsonprocessing.constants.GlobalConstants;
import com.example.jsonprocessing.model.dto.CategorySeedDto;
import com.example.jsonprocessing.model.entities.Category;
import com.example.jsonprocessing.repositories.CategoryRepository;
import com.example.jsonprocessing.services.CategoryService;
import com.example.jsonprocessing.util.ValidationUtil;
import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.concurrent.ThreadLocalRandom;

@Service
public class CategoryServiceImpl implements CategoryService {
    private static final String FILE_NAME = "categories.json";
    private final CategoryRepository categoryRepository;
    private final ValidationUtil validationUtil;
    private final Gson gson;
    private final ModelMapper modelMapper;

    public CategoryServiceImpl(CategoryRepository categoryRepository, ValidationUtil validationUtil, Gson gson, ModelMapper modelMapper) {
        this.categoryRepository = categoryRepository;
        this.validationUtil = validationUtil;
        this.gson = gson;
        this.modelMapper = modelMapper;
    }

    @Override
    public void seedDataFromJson() throws IOException {
        if (this.categoryRepository.count() > 0) {
            return;
        }
        String jsonFile = Files.readString(Path.of(GlobalConstants.JSON_FILE_PATH + FILE_NAME));
        CategorySeedDto[] categorySeedDtos = this.gson.fromJson(jsonFile, CategorySeedDto[].class);
        Arrays.stream(categorySeedDtos)
                .filter(this.validationUtil::isValid)
                .map(categorySeedDto -> this.modelMapper.map(categorySeedDto, Category.class))
                .forEach(this.categoryRepository::save);
    }

    public Category getRandomCategory() {
        return this.categoryRepository.findById(ThreadLocalRandom.current().nextLong(1, this.categoryRepository.count() + 1)).orElse(null);
    }

    public long count() {
        return this.categoryRepository.count();
    }
}
