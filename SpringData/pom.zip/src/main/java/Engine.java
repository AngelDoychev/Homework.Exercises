import entities.Address;
import entities.Employee;
import entities.Project;
import entities.Town;

import javax.persistence.EntityManager;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.stream.Collectors;

public class Engine implements Runnable {
    private final EntityManager entityManager;

    public Engine(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Override
    public void run() {
        System.out.println("Please select which Exercise you want to load!");
        Scanner scanner = new Scanner(System.in);
        int ex = Integer.parseInt(scanner.nextLine());
        switch (ex) {
            case 1 -> System.out.println("Already completed in IntelliJ");
            case 2 -> ex2();
            case 3 -> ex3();
            case 4 -> ex4();
            case 5 -> ex5();
            case 6 -> ex6();
            case 7 -> ex7();
            case 8 -> ex8();
            case 9 -> ex9();
            case 10 -> ex10();
            case 11 -> ex11();
            case 12 -> ex12();
            case 13 -> ex13();
        }
    }

    private void ex13() {
        System.out.println("Please provide the name of the town you wish to delete!");
        Scanner scanner = new Scanner(System.in);
        String givenTownName = scanner.nextLine();
        Town townToRemove = entityManager.createQuery("SELECT t FROM Town t " +
                        "WHERE t.name = :name ", Town.class)
                .setParameter("name", givenTownName)
                .getSingleResult();
        int removedAddressesCount = removeAddresses(townToRemove.getId());
        entityManager.getTransaction().begin();
        entityManager.remove(townToRemove);
        entityManager.getTransaction().commit();
        System.out.printf("%d addresses in %s deleted %n", removedAddressesCount, givenTownName);
    }

    private int removeAddresses(int id) {
        List<Address> addresses = entityManager.createQuery("SELECT a FROM Address a " +
                        "Where a.town.id = :givenID ", Address.class)
                .setParameter("givenID", id)
                .getResultList();
        entityManager.getTransaction().begin();
        addresses.forEach(entityManager::remove);
        entityManager.getTransaction().commit();
        return addresses.size();
    }

    private void ex12() {
        List<Object[]> objects = entityManager.createNativeQuery("SELECT d.name, MAX(e.salary) AS max_salary FROM departments AS d " +
                        "JOIN employees AS e " +
                        "ON d.department_id = e.department_id " +
                        "GROUP BY d.name " +
                        "HAVING max_salary NOT BETWEEN 30000 AND 70000 ")
                .getResultList();
        objects.forEach(e -> System.out.printf("%s $%.2f%n", e[0], e[1]));
    }

    private void ex11() {
        Scanner scanner = new Scanner(System.in);
        String str = scanner.nextLine();
        entityManager.createQuery("SELECT e FROM Employee e " +
                        "WHERE e.firstName LIKE :str", Employee.class)
                .setParameter("str", str + "%")
                .getResultList()
                .forEach(e -> System.out.printf("%s %s %s - ($%.2f)%n"
                        , e.getFirstName()
                        , e.getLastName()
                        , e.getJobTitle()
                        , e.getSalary()));
    }

    private void ex10() {
        entityManager.getTransaction().begin();
        int num = entityManager.createQuery("UPDATE Employee e " +
                        "SET e.salary = e.salary * 1.12 " +
                        "WHERE e.department.id IN :ids ")
                .setParameter("ids", Set.of(1, 2, 4, 11))
                .executeUpdate();
        entityManager.getTransaction().commit();
        entityManager.createQuery("SELECT e FROM Employee e " +
                        "WHERE e.department.id IN :ids ", Employee.class)
                .setParameter("ids", Set.of(1, 2, 4, 11))
                .getResultList().forEach(e -> System.out.printf("%s %s ($%.2f%n)"
                        , e.getFirstName()
                        , e.getLastName()
                        , e.getSalary()));
    }

    private void ex9() {
        entityManager.createQuery("SELECT p FROM Project p " +
                        "ORDER BY p.name ", Project.class)
                .setMaxResults(10)
                .getResultList()
                .forEach(p -> System.out.printf("Project name: %s%n" +
                                "Project description: %s%n" +
                                "Project Start Date: %s%n" +
                                "Project End Date: %s%n"
                        , p.getName()
                        , p.getDescription()
                        , p.getStartDate()
                        , p.getEndDate()));
    }

    private void ex8() {
        Scanner scanner = new Scanner(System.in);
        int givenID = Integer.parseInt(scanner.nextLine());
        Employee employee = entityManager.createQuery("SELECT e FROM Employee e " +
                        "WHERE e.id = :givenID ", Employee.class)
                .setParameter("givenID", givenID)
                .getSingleResult();
        System.out.printf("%s %s - %s %s%n"
                , employee.getFirstName()
                , employee.getLastName()
                , employee.getDepartment().getName()
                , employee.getJobTitle());
        employee.getProjects().stream().map(Project::getName).sorted().forEach(p -> System.out.printf("%s%n", p));
    }

    private void ex7() {
        entityManager.createQuery("SELECT a FROM Address a " +
                        "ORDER BY a.employees.size DESC ", Address.class)
                .setMaxResults(10)
                .getResultList()
                .forEach(a -> System.out.printf("%s, %s - %d employees%n"
                        , a.getText()
                        , a.getTown() == null ? "No Town" : a.getTown().getName()
                        , a.getEmployees().size()));
    }

    private void ex6() {
        Scanner scanner = new Scanner(System.in);
        String lastName = scanner.nextLine();
        Address address = new Address();
        address.setText("Vitoshka 15");
        entityManager.getTransaction().begin();
        entityManager.persist(address);
        entityManager.getTransaction().commit();
        Employee employee = entityManager.createQuery("SELECT e FROM Employee e " +
                        "WHERE e.lastName = :lastName", Employee.class)
                .setParameter("lastName", lastName)
                .getSingleResult();
        entityManager.getTransaction().begin();
        employee.setAddress(address);
        entityManager.getTransaction().commit();
    }

    private void ex5() {
        entityManager.createQuery("SELECT e FROM Employee e " +
                        "WHERE e.department.name = :department " +
                        "ORDER BY e.salary, e.id", Employee.class)
                .setParameter("department", "Research and Development")
                .getResultList()
                .forEach(e -> System.out.printf("%s %s %s - $%.2f%n", e.getFirstName(),
                        e.getLastName(),
                        e.getDepartment().getName(),
                        e.getSalary()));
    }

    private void ex4() {
        entityManager.createQuery("SELECT e FROM Employee e " +
                        "WHERE e.salary > 50000", Employee.class)
                .getResultList()
                .stream()
                .map(Employee::getFirstName)
                .forEach(System.out::println);
    }

    private void ex3() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please select a name you want to check!");
        String[] fullName = scanner.nextLine().split("\\s+");
        String firstName = fullName[0];
        String lastName = fullName[1];
        long employeeCount = entityManager.createQuery("SELECT count(e) FROM Employee e " +
                        "WHERE e.firstName = :firstName AND e.lastName = :lastName ", Long.class)
                .setParameter("firstName", firstName)
                .setParameter("lastName", lastName)
                .getSingleResult();
        System.out.println(employeeCount == 0 ? "No" : "Yes");
    }

    private void ex2() {
        entityManager.getTransaction().begin();
        entityManager.createQuery("UPDATE Town t " +
                "SET t.name = UPPER(t.name) " +
                "WHERE LENGTH(t.name) <= 5 ").executeUpdate();
        entityManager.getTransaction().commit();
    }
}
