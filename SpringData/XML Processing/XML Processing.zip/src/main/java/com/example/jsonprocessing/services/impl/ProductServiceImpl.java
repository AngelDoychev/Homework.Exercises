package com.example.jsonprocessing.services.impl;

import com.example.jsonprocessing.constants.GlobalConstants;
import com.example.jsonprocessing.model.dto.jsonDtos.ProductSeedDto;
import com.example.jsonprocessing.model.dto.xmlDtos.XmlProductSeedRootDto;
import com.example.jsonprocessing.model.entities.Category;
import com.example.jsonprocessing.model.entities.Product;
import com.example.jsonprocessing.repositories.ProductRepository;
import com.example.jsonprocessing.repositories.UserRepository;
import com.example.jsonprocessing.services.CategoryService;
import com.example.jsonprocessing.services.ProductService;
import com.example.jsonprocessing.util.ValidationUtil;
import com.example.jsonprocessing.util.XmlParser;
import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import javax.xml.bind.JAXBException;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

@Service
public class ProductServiceImpl implements ProductService {
    private static final String JSON_FILE_NAME = "products.json";
    private static final String XML_FILE_NAME = "products.xml";
    private final ProductRepository productRepository;
    private final UserRepository userRepository;
    private final ValidationUtil validationUtil;
    private final CategoryService categoryService;
    private final Gson gson;
    private final ModelMapper modelMapper;
    private final XmlParser xmlParser;

    public ProductServiceImpl(ProductRepository productRepository, UserRepository userRepository, ValidationUtil validationUtil, CategoryService categoryService, Gson gson, ModelMapper modelMapper, XmlParser xmlParser) {
        this.productRepository = productRepository;
        this.userRepository = userRepository;
        this.validationUtil = validationUtil;
        this.categoryService = categoryService;
        this.gson = gson;
        this.modelMapper = modelMapper;
        this.xmlParser = xmlParser;
    }

    @Override
    public void seedDataFromJson() throws IOException {
        if (this.productRepository.count() > 0) {
            return;
        }
        String jsonFile = Files.readString(Path.of(GlobalConstants.INPUT_FILE_PATH + JSON_FILE_NAME));
        ProductSeedDto[] productSeedDtos = this.gson.fromJson(jsonFile, ProductSeedDto[].class);
        Arrays.stream(productSeedDtos)
                .filter(this.validationUtil::isValid)
                .map(product -> this.modelMapper.map(product, Product.class))
                .map(product -> {
                    long randomSellerId = ThreadLocalRandom.current().nextLong(1, this.userRepository.count() + 1);
                    product.setSeller(this.userRepository.findById(randomSellerId).orElse(null));
                    if (product.getPrice().compareTo(BigDecimal.valueOf(800L)) > 0){
                        long randomBuyerId = ThreadLocalRandom.current().nextLong(1, this.userRepository.count() + 1);
                        product.setBuyer(this.userRepository.findById(randomBuyerId).orElse(null));
                    }
                    Set<Category> categories = new HashSet<>();
                    int num = ThreadLocalRandom.current().nextInt(1, 3);
                    for (int i = 0; i < num; i++) {
                        categories.add(this.categoryService.getRandomCategory());
                    }
                    product.setCategories(categories);
                    return product;
                })
                .forEach(this.productRepository::save);
    }

    @Override
    public void seedDataFromXml() throws JAXBException, FileNotFoundException {
        if (this.productRepository.count() > 0) {
            return;
        }
        XmlProductSeedRootDto xmlProductSeedRootDto = this.xmlParser.fromFile(GlobalConstants.INPUT_FILE_PATH + XML_FILE_NAME, XmlProductSeedRootDto.class);
        xmlProductSeedRootDto.getProducts()
                .stream()
                .filter(this.validationUtil::isValid)
                .map(productSeedDto -> this.modelMapper.map(productSeedDto, Product.class))
                .map(product -> {
                    long randomSellerId = ThreadLocalRandom.current().nextLong(1, this.userRepository.count() + 1);
                    product.setSeller(this.userRepository.findById(randomSellerId).orElse(null));
                    if (product.getPrice().compareTo(BigDecimal.valueOf(800L)) > 0){
                        long randomBuyerId = ThreadLocalRandom.current().nextLong(1, this.userRepository.count() + 1);
                        product.setBuyer(this.userRepository.findById(randomBuyerId).orElse(null));
                    }
                    Set<Category> categories = new HashSet<>();
                    int num = ThreadLocalRandom.current().nextInt(1, 3);
                    for (int i = 0; i < num; i++) {
                        categories.add(this.categoryService.getRandomCategory());
                    }
                    product.setCategories(categories);
                    return product;
                })
                .forEach(this.productRepository::save);
    }

    @Override
    public List<Product> findAllByPriceBetweenAndBuyerIsNullOrderByPrice(BigDecimal lower, BigDecimal upper) {
        return this.productRepository.findAllByPriceBetweenAndBuyerIsNullOrderByPrice(lower, upper);
    }
}
