package com.example.jsonprocessing.services.impl;

import com.example.jsonprocessing.constants.GlobalConstants;
import com.example.jsonprocessing.model.dto.jsonDtos.CategorySeedDto;
import com.example.jsonprocessing.model.dto.xmlDtos.XmlCategorySeedRootDto;
import com.example.jsonprocessing.model.entities.Category;
import com.example.jsonprocessing.repositories.CategoryRepository;
import com.example.jsonprocessing.services.CategoryService;
import com.example.jsonprocessing.util.ValidationUtil;
import com.example.jsonprocessing.util.XmlParser;
import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.concurrent.ThreadLocalRandom;

@Service
public class CategoryServiceImpl implements CategoryService {
    private static final String JSON_FILE_NAME = "categories.json";
    private static final String XML_FILE_NAME = "categories.xml";
    private final CategoryRepository categoryRepository;
    private final ValidationUtil validationUtil;
    private final Gson gson;
    private final ModelMapper modelMapper;
    private final XmlParser xmlParser;

    public CategoryServiceImpl(CategoryRepository categoryRepository, ValidationUtil validationUtil, Gson gson, ModelMapper modelMapper, XmlParser xmlParser) {
        this.categoryRepository = categoryRepository;
        this.validationUtil = validationUtil;
        this.gson = gson;
        this.modelMapper = modelMapper;
        this.xmlParser = xmlParser;
    }

    @Override
    public void seedDataFromJson() throws IOException {
        if (this.categoryRepository.count() > 0) {
            return;
        }
        String jsonFile = Files.readString(Path.of(GlobalConstants.INPUT_FILE_PATH + JSON_FILE_NAME));
        CategorySeedDto[] categorySeedDtos = this.gson.fromJson(jsonFile, CategorySeedDto[].class);
        Arrays.stream(categorySeedDtos)
                .filter(this.validationUtil::isValid)
                .map(categorySeedDto -> this.modelMapper.map(categorySeedDto, Category.class))
                .forEach(this.categoryRepository::save);
    }

    @Override
    public void seedDataFromXml() throws IOException, JAXBException {
        if (this.categoryRepository.count() > 0) {
            return;
        }
        XmlCategorySeedRootDto xmlCategorySeedRootDto = this.xmlParser.fromFile(GlobalConstants.INPUT_FILE_PATH + XML_FILE_NAME, XmlCategorySeedRootDto.class);
        xmlCategorySeedRootDto.getCategories()
                .stream()
                .filter(this.validationUtil::isValid)
                .map(categorySeedDto -> this.modelMapper.map(categorySeedDto, Category.class))
                .forEach(this.categoryRepository::save);
    }

    public Category getRandomCategory() {
        return this.categoryRepository.findById(ThreadLocalRandom.current().nextLong(1, this.categoryRepository.count() + 1)).orElse(null);
    }

    public long count() {
        return this.categoryRepository.count();
    }
}
