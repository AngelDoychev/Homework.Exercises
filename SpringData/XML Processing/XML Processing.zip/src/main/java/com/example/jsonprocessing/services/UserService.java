package com.example.jsonprocessing.services;

import javax.xml.bind.JAXBException;
import java.io.FileNotFoundException;
import java.io.IOException;

public interface UserService {
    void seedDataFromJson() throws IOException;
    void seedDataFromXml() throws JAXBException, FileNotFoundException;
}
