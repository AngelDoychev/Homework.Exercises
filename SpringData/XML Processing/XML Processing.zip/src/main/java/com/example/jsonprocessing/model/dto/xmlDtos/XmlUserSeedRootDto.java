package com.example.jsonprocessing.model.dto.xmlDtos;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "users")
@XmlAccessorType(XmlAccessType.FIELD)
public class XmlUserSeedRootDto {
    @XmlElement(name = "user")
    List<XmlUserSeedDto> users;

    public XmlUserSeedRootDto() {
    }

    public List<XmlUserSeedDto> getUsers() {
        return users;
    }

    public void setUsers(List<XmlUserSeedDto> users) {
        this.users = users;
    }
}
