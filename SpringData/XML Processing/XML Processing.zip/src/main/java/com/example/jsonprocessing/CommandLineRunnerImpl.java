package com.example.jsonprocessing;

import com.example.jsonprocessing.model.dto.jsonDtos.ProductPrintNamePriceAndSellerDto;
import com.example.jsonprocessing.model.dto.xmlDtos.XmlProductPrintDto;
import com.example.jsonprocessing.model.dto.xmlDtos.XmlProductPrintRootDto;
import com.example.jsonprocessing.model.entities.Product;
import com.example.jsonprocessing.services.CategoryService;
import com.example.jsonprocessing.services.ProductService;
import com.example.jsonprocessing.services.UserService;
import com.example.jsonprocessing.util.XmlParser;
import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

@Component
public class CommandLineRunnerImpl implements CommandLineRunner {
    private final Scanner scanner;
    private final CategoryService categoryService;
    private final ProductService productService;
    private final UserService userService;
    private final Gson gson;
    private final ModelMapper modelMapper;
    private final XmlParser xmlParser;

    public CommandLineRunnerImpl(CategoryService categoryService, ProductService productService, UserService userService, Gson gson, ModelMapper modelMapper, XmlParser xmlParser) {
        this.categoryService = categoryService;
        this.productService = productService;
        this.userService = userService;
        this.gson = gson;
        this.modelMapper = modelMapper;
        this.xmlParser = xmlParser;
        scanner = new Scanner(System.in);
    }

    @Override
    public void run(String... args) throws Exception {
        System.out.println("Please select type of date you want to parse!");
        String formatSeedType = this.scanner.nextLine();
        switch (formatSeedType) {
            case "json" -> seedDataFromJson();
            case "xml" -> seedDataFromXml();
        }
        System.out.println("Please select exercise number!");
        int exerciseNumber = Integer.parseInt(this.scanner.nextLine());
        switch (exerciseNumber) {
            case 1 -> exerciseJSON();
            case 2 -> exerciseXML();

        }
    }

    private void seedDataFromXml() throws IOException, JAXBException {
        this.categoryService.seedDataFromXml();
        this.userService.seedDataFromXml();
        this.productService.seedDataFromXml();
    }

    private void exerciseXML() throws JAXBException {
        XmlProductPrintRootDto rootDto = new XmlProductPrintRootDto();
         rootDto.setProducts(this.productService.findAllByPriceBetweenAndBuyerIsNullOrderByPrice(new BigDecimal("500"), new BigDecimal("1000")) .stream()
                .map(product -> {
                    XmlProductPrintDto productDto = this.modelMapper.map(product, XmlProductPrintDto.class);
                    productDto.setSeller(String.format("%s %s",
                            product.getSeller().getFirstName(),
                            product.getSeller().getLastName()));
                    return productDto;
                })
                .collect(Collectors.toList()));
        this.xmlParser.writeToFile("src/main/resources/files/xmlTargetFile/ex1.xml", rootDto);
    }


    private void exerciseJSON() throws IOException {
        List<Product> products = this.productService.findAllByPriceBetweenAndBuyerIsNullOrderByPrice(new BigDecimal("500"), new BigDecimal("1000"));
        List<ProductPrintNamePriceAndSellerDto> productsDto = products
                .stream()
                .map(product -> {
                    ProductPrintNamePriceAndSellerDto productDto = this.modelMapper.map(product, ProductPrintNamePriceAndSellerDto.class);
                    productDto.setSeller(String.format("%s %s",
                            product.getSeller().getFirstName(),
                            product.getSeller().getLastName()));
                    return productDto;
                })

                .collect(Collectors.toList());

        String productJson = this.gson.toJson(productsDto);
        Files.write(Path.of("src/main/resources/files/jsonTargetFile/ex1.json"), Collections.singleton(productJson));
    }

    private void seedDataFromJson() throws IOException {
        this.categoryService.seedDataFromJson();
        this.userService.seedDataFromJson();
        this.productService.seedDataFromJson();
    }
}
