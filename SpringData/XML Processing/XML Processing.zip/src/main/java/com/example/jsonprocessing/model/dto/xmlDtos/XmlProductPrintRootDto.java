package com.example.jsonprocessing.model.dto.xmlDtos;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "products")
@XmlAccessorType(XmlAccessType.FIELD)
public class XmlProductPrintRootDto {
    @XmlElement(name = "product")
    private List<XmlProductPrintDto> products;

    public XmlProductPrintRootDto() {
    }

    public List<XmlProductPrintDto> getProducts() {
        return products;
    }

    public void setProducts(List<XmlProductPrintDto> products) {
        this.products = products;
    }
}
