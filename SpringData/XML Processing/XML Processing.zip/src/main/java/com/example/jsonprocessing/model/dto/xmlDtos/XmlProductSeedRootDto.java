package com.example.jsonprocessing.model.dto.xmlDtos;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "products")
@XmlAccessorType(XmlAccessType.FIELD)
public class XmlProductSeedRootDto {
    @XmlElement(name = "product")
    List<XmlProductSeedDto> products;

    public XmlProductSeedRootDto() {
    }

    public List<XmlProductSeedDto> getProducts() {
        return products;
    }

    public void setProducts(List<XmlProductSeedDto> products) {
        this.products = products;
    }
}
