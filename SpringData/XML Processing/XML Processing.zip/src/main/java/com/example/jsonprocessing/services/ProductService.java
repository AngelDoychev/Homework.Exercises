package com.example.jsonprocessing.services;

import com.example.jsonprocessing.model.entities.Product;

import javax.xml.bind.JAXBException;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

public interface ProductService {
    void seedDataFromJson() throws IOException;
    void seedDataFromXml() throws JAXBException, FileNotFoundException;
    List<Product> findAllByPriceBetweenAndBuyerIsNullOrderByPrice(BigDecimal lower, BigDecimal upper);
}
