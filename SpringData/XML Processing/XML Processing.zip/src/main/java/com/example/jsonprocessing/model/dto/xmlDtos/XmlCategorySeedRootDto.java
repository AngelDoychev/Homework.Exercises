package com.example.jsonprocessing.model.dto.xmlDtos;

import com.example.jsonprocessing.model.dto.jsonDtos.CategorySeedDto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "categories")
@XmlAccessorType(XmlAccessType.FIELD)
public class XmlCategorySeedRootDto {
    @XmlElement(name = "category")
    private List<XmlCategorySeedDto> categories;

    public XmlCategorySeedRootDto() {
    }

    public List<XmlCategorySeedDto> getCategories() {
        return categories;
    }

    public void setCategories(List<XmlCategorySeedDto> categories) {
        this.categories = categories;
    }
}
