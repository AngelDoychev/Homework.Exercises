package com.example.jsonprocessing.services.impl;

import com.example.jsonprocessing.constants.GlobalConstants;
import com.example.jsonprocessing.model.dto.jsonDtos.UserSeedDto;
import com.example.jsonprocessing.model.dto.xmlDtos.XmlUserSeedRootDto;
import com.example.jsonprocessing.model.entities.User;
import com.example.jsonprocessing.repositories.UserRepository;
import com.example.jsonprocessing.services.UserService;
import com.example.jsonprocessing.util.ValidationUtil;
import com.example.jsonprocessing.util.XmlParser;
import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import javax.xml.bind.JAXBException;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

@Service
public class UserServiceImpl implements UserService {
    private static final String JSON_FILE_NAME = "users.json";
    private static final String XML_FILE_NAME = "users.xml";
    private final UserRepository userRepository;
    private final ValidationUtil validationUtil;
    private final Gson gson;
    private final ModelMapper modelMapper;
    private final XmlParser xmlParser;

    public UserServiceImpl(UserRepository userRepository, ValidationUtil validationUtil, Gson gson, ModelMapper modelMapper, XmlParser xmlParser) {
        this.userRepository = userRepository;
        this.validationUtil = validationUtil;
        this.gson = gson;
        this.modelMapper = modelMapper;
        this.xmlParser = xmlParser;
    }

    @Override
    public void seedDataFromJson() throws IOException {
        if (this.userRepository.count() > 0) {
            return;
        }
        String jsonFile = Files.readString(Path.of(GlobalConstants.INPUT_FILE_PATH + JSON_FILE_NAME));
        UserSeedDto[] userSeedDtos = this.gson.fromJson(jsonFile, UserSeedDto[].class);
        Arrays.stream(userSeedDtos)
                .filter(this.validationUtil::isValid)
                .map(user -> this.modelMapper.map(user, User.class))
                .forEach(this.userRepository::save);
    }

    @Override
    public void seedDataFromXml() throws JAXBException, FileNotFoundException {
        if (this.userRepository.count() > 0) {
            return;
        }
        XmlUserSeedRootDto xmlUserSeedRootDto = this.xmlParser.fromFile(GlobalConstants.INPUT_FILE_PATH + XML_FILE_NAME, XmlUserSeedRootDto.class);
        xmlUserSeedRootDto.getUsers()
                .stream()
                .filter(this.validationUtil::isValid)
                .map(userSeedDto -> this.modelMapper.map(userSeedDto, User.class))
                .forEach(this.userRepository::save);
    }
}
