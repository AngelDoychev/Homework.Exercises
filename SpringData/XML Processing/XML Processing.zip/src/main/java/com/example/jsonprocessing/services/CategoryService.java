package com.example.jsonprocessing.services;

import com.example.jsonprocessing.model.entities.Category;

import javax.xml.bind.JAXBException;
import java.io.IOException;

public interface CategoryService {
    void seedDataFromJson() throws IOException;
    void seedDataFromXml() throws IOException, JAXBException;
    long count();
    Category getRandomCategory();
}
