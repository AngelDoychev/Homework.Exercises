package softuni.exam.models.entity.Enums;

public enum CarType {
    SUV, coupe, sport
}
