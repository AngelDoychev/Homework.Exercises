package softuni.exam.service.impl;

import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.PartSeedDto;
import softuni.exam.models.entity.Part;
import softuni.exam.repository.PartRepository;
import softuni.exam.service.PartService;
import softuni.exam.util.ValidationUtil;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

@Service
public class PartServiceImpl implements PartService {
    private final PartRepository partRepository;
    private final Gson gson;
    private final ModelMapper modelMapper;
    private final ValidationUtil validationUtil;
    public static final String PART_FILE_PATH = "src/main/resources/files/json/parts.json";

    public PartServiceImpl(PartRepository partRepository, Gson gson, ModelMapper modelMapper, ValidationUtil validationUtil) {
        this.partRepository = partRepository;
        this.gson = gson;
        this.modelMapper = modelMapper;
        this.validationUtil = validationUtil;
    }

    @Override
    public boolean areImported() {
        return this.partRepository.count() > 0;
    }

    @Override
    public String readPartsFileContent() throws IOException {
        return Files.readString(Path.of(PART_FILE_PATH));
    }

    @Override
    public String importParts() throws IOException {
        StringBuilder sb = new StringBuilder();
        Arrays.stream(this.gson.fromJson(this.readPartsFileContent(), PartSeedDto[].class))
                .filter(partSeedDto -> {
                    boolean isValid = this.validationUtil.isValid(partSeedDto) && null == this.partRepository.findPartByPartName(partSeedDto.getPartName());
                    if (isValid) {
                        sb.append(String.format("Successfully imported part %s – %.2f%n", partSeedDto.getPartName(), partSeedDto.getPrice()));
                    } else {
                        sb.append("Invalid part\n");
                    }
                    return isValid;
                }).map(partSeedDto -> this.modelMapper.map(partSeedDto, Part.class))
                .forEach(this.partRepository::save);
        return sb.toString();
    }
    @Override
    public Part findById(long id){
        return this.partRepository.findById(id).orElse(null);
    }
}
