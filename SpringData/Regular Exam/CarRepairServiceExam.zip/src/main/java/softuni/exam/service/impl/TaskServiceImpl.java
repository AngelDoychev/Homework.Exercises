package softuni.exam.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.TaskSeedRootDto;
import softuni.exam.models.entity.Enums.CarType;
import softuni.exam.models.entity.Task;
import softuni.exam.repository.TaskRepository;
import softuni.exam.service.CarService;
import softuni.exam.service.MechanicService;
import softuni.exam.service.PartService;
import softuni.exam.service.TaskService;
import softuni.exam.util.ValidationUtil;
import softuni.exam.util.XmlParser;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

@Service
public class TaskServiceImpl implements TaskService {
    private final TaskRepository taskRepository;
    private final ModelMapper modelMapper;
    private final ValidationUtil validationUtil;
    private final XmlParser xmlParser;
    private final CarService carService;
    private final MechanicService mechanicService;
    private final PartService partService;
    private static final String TASKS_FILE_PATH = "src/main/resources/files/xml/tasks.xml";

    public TaskServiceImpl(TaskRepository taskRepository, ModelMapper modelMapper, ValidationUtil validationUtil, XmlParser xmlParser, CarService carService, MechanicService mechanicService, PartService partService) {
        this.taskRepository = taskRepository;
        this.modelMapper = modelMapper;
        this.validationUtil = validationUtil;
        this.xmlParser = xmlParser;
        this.carService = carService;
        this.mechanicService = mechanicService;
        this.partService = partService;
    }

    @Override
    public boolean areImported() {
        return this.taskRepository.count() > 0;
    }

    @Override
    public String readTasksFileContent() throws IOException {
        return Files.readString(Path.of(TASKS_FILE_PATH));
    }

    @Override
    public String importTasks() throws IOException, JAXBException {
        StringBuilder sb = new StringBuilder();
        this.xmlParser.fromFile(TASKS_FILE_PATH, TaskSeedRootDto.class).getTasks()
                .stream()
                .filter(taskSeedDto -> {
                    boolean isValid = this.validationUtil.isValid(taskSeedDto)
                            && null != this.mechanicService.findByFirstName(taskSeedDto.getMechanic().getFirstName());
                    if (isValid) {
                        sb.append(String.format("Successfully imported task %.2f%n", taskSeedDto.getPrice()));
                    } else {
                        sb.append("Invalid task\n");
                    }
                    return isValid;
                })
                .map(taskSeedDto -> {
                    Task task = this.modelMapper.map(taskSeedDto, Task.class);
                    task.setCar(this.carService.findById(taskSeedDto.getCar().getId()));
                    task.setMechanic(this.mechanicService.findByFirstName(taskSeedDto.getMechanic().getFirstName()));
                    task.setPart(this.partService.findById(taskSeedDto.getPart().getId()));
                    return task;
                })
                .forEach(this.taskRepository::save);
        return sb.toString();
    }

    @Override
    public String getCoupeCarTasksOrderByPrice() {
        StringBuilder sb = new StringBuilder();
        this.taskRepository.findAllByCar_CarTypeOrderByPrice(CarType.coupe)
                .forEach(task -> sb.append(String.format("Car %s %s with %dkm%n" +
                                "-Mechanic: %s %s - task №%d:%n" +
                                "--Engine: %.2f%n" +
                                "---Price: %.2f$%n",
                        task.getCar().getCarMake(),
                        task.getCar().getCarModel(),
                        task.getCar().getKilometers(),
                        task.getMechanic().getFirstName(),
                        task.getMechanic().getLastName(),
                        task.getId(),
                        task.getCar().getEngine(),
                        task.getPrice())));
        return sb.toString();
    }
}
