package softuni.exam.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.CarSeedRootDto;
import softuni.exam.models.entity.Car;
import softuni.exam.repository.CarRepository;
import softuni.exam.service.CarService;
import softuni.exam.util.ValidationUtil;
import softuni.exam.util.XmlParser;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

@Service

public class CarServiceImpl implements CarService {
    private final CarRepository carRepository;
    private final ValidationUtil validationUtil;
    private final ModelMapper modelMapper;
    private final XmlParser xmlParser;
    private static final String CAR_FILE_PATH = "src/main/resources/files/xml/cars.xml";

    public CarServiceImpl(CarRepository carRepository, ValidationUtil validationUtil, ModelMapper modelMapper, XmlParser xmlParser) {
        this.carRepository = carRepository;
        this.validationUtil = validationUtil;
        this.modelMapper = modelMapper;
        this.xmlParser = xmlParser;
    }

    @Override
    public boolean areImported() {
        return this.carRepository.count() > 0;
    }

    @Override
    public String readCarsFromFile() throws IOException {
        return Files.readString(Path.of(CAR_FILE_PATH));
    }

    @Override
    public String importCars() throws IOException, JAXBException {
        StringBuilder sb = new StringBuilder();
        this.xmlParser.fromFile(CAR_FILE_PATH, CarSeedRootDto.class).getCars()
                .stream()
                .filter(carSeedDto -> {
                    boolean isValid = this.validationUtil.isValid(carSeedDto) && null == this.carRepository.findCarByPlateNumber(carSeedDto.getPlateNumber());
                    if (isValid) {
                        sb.append(String.format("Successfully imported car %s - %s%n", carSeedDto.getCarMake(), carSeedDto.getCarModel()));
                    } else {
                        sb.append("Invalid car\n");
                    }
                    return isValid;
                })
                .map(carSeedDto -> this.modelMapper.map(carSeedDto, Car.class))
                .forEach(this.carRepository::save);
        return sb.toString();
    }
    @Override
    public Car findById(long id) {
        return this.carRepository.findById(id).orElse(null);
    }
}
