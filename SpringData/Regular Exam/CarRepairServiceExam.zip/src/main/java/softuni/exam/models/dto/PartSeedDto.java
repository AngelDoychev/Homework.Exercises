package softuni.exam.models.dto;

import com.google.gson.annotations.Expose;

import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;
import java.math.BigDecimal;

public class PartSeedDto {
    @Expose
    @Size(min = 2, max = 19)
    private String partName;
    @Expose
    @DecimalMin("10")
    @DecimalMax("2000")
    private BigDecimal price;
    @Expose
    @Positive
    private int quantity;

    public PartSeedDto() {
    }

    public String getPartName() {
        return partName;
    }

    public void setPartName(String partName) {
        this.partName = partName;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
