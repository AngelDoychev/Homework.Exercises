package com.example.springdataautomappingobjects.services;

import com.example.springdataautomappingobjects.models.dto.EmployeeDto;
import com.example.springdataautomappingobjects.models.dto.ManagerDto;
import com.example.springdataautomappingobjects.models.entities.Employee;

import java.util.List;

public interface EmployeeService {
    EmployeeDto findEmployeeDtoById(long id);
    ManagerDto findManagerDtoById(long id);
    List<Employee> findAll();
}
