package com.example.springdataautomappingobjects;

import com.example.springdataautomappingobjects.models.dto.EmployeeDto;
import com.example.springdataautomappingobjects.models.dto.ManagerDto;
import com.example.springdataautomappingobjects.services.EmployeeService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Scanner;

@Component
public class CommandLineRunnerImpl implements CommandLineRunner {
    private final EmployeeService employeeService;

    public CommandLineRunnerImpl(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @Override
    public void run(String... args) throws Exception {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please select exercise number!");
        int exerciseNum = Integer.parseInt(scanner.nextLine());
        switch (exerciseNum) {
            case 1 -> exercise1();
            case 2 -> exercise2();
        }
    }

    private void exercise2() {
        ManagerDto managerDto = this.employeeService.findManagerDtoById(1L);
        System.out.printf("%s %s | Employees: %d%n"
                , managerDto.getFirstName()
                , managerDto.getLastName()
                , managerDto.getSubordinates().size());
        managerDto.getSubordinates()
                .forEach(employee -> System.out.printf("%s %s %.2f%n"
                        , employee.getFirstName()
                        , employee.getLastName()
                        , employee.getSalary()));

    }

    private void exercise1() {
        EmployeeDto employeeDto = this.employeeService.findEmployeeDtoById(1L);
        System.out.printf("%s %s : %.2flv%n"
                , employeeDto.getFirstName()
                , employeeDto.getLastName()
                , employeeDto.getSalary());
    }
}
