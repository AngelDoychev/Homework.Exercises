package com.example.springdataautomappingobjects.services;

import com.example.springdataautomappingobjects.models.dto.EmployeeDto;
import com.example.springdataautomappingobjects.models.dto.ManagerDto;
import com.example.springdataautomappingobjects.models.entities.Employee;
import com.example.springdataautomappingobjects.repositories.EmployeeRepository;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeServiceImpl implements EmployeeService{
    private final EmployeeRepository employeeRepository;

    public EmployeeServiceImpl(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    @Override
    public EmployeeDto findEmployeeDtoById(long id) {
        Employee employee = this.employeeRepository.findById(id).orElseThrow();
        EmployeeDto employeeDto = new EmployeeDto();
        employeeDto.setFirstName(employee.getFirstName());
        employeeDto.setLastName(employee.getLastName());
        employeeDto.setSalary(employee.getSalary());
        return employeeDto;
    }

    @Override
    public ManagerDto findManagerDtoById(long id) {
        ModelMapper modelMapper = new ModelMapper();
        return modelMapper.map(this.employeeRepository.findById(id).orElseThrow(), ManagerDto.class);
    }

    @Override
    public List<Employee> findAll() {
        return this.employeeRepository.findAll();
    }
}
