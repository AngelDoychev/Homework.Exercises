package com.example.springdataautomappingobjectsexercise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataAutoMappingObjectsExerciseApplicationTests {

	@Test
	void contextLoads() {
	}

}
