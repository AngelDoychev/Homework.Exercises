package com.example.springdataautomappingobjectsexercise.models.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

public class GamePrintDetailsDto {
    private String title;
    private BigDecimal price;
    private String description;
    private LocalDate releaseDAte;

    public GamePrintDetailsDto() {
    }

    public GamePrintDetailsDto(String title, BigDecimal price, String description, LocalDate releaseDAte) {
        this.title = title;
        this.price = price;
        this.description = description;
        this.releaseDAte = releaseDAte;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDate getReleaseDAte() {
        return releaseDAte;
    }

    public void setReleaseDAte(LocalDate releaseDAte) {
        this.releaseDAte = releaseDAte;
    }
}
