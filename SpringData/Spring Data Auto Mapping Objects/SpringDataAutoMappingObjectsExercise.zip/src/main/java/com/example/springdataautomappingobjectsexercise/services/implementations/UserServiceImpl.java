package com.example.springdataautomappingobjectsexercise.services.implementations;

import com.example.springdataautomappingobjectsexercise.models.dto.UserLoginDto;
import com.example.springdataautomappingobjectsexercise.models.dto.UserRegisterDto;
import com.example.springdataautomappingobjectsexercise.models.entities.User;
import com.example.springdataautomappingobjectsexercise.repositories.UserRepository;
import com.example.springdataautomappingobjectsexercise.services.UserService;
import com.example.springdataautomappingobjectsexercise.util.ValidationUtil;
import jakarta.validation.ConstraintViolation;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.Set;

@Service
public class UserServiceImpl implements UserService {
    private final UserRepository userRepository;
    private final ModelMapper modelMapper;
    private final ValidationUtil validationUtil;
    private final GameServiceImpl gameServiceImpl;
    private User loggedInUser;

    public UserServiceImpl(UserRepository userRepository, ModelMapper modelMapper, ValidationUtil validationUtil, GameServiceImpl gameServiceImpl) {
        this.userRepository = userRepository;
        this.modelMapper = modelMapper;
        this.validationUtil = validationUtil;
        this.gameServiceImpl = gameServiceImpl;
    }

    @Override
    public void registerUser(UserRegisterDto userRegisterDto) {
        if (!userRegisterDto.getPassword().equals(userRegisterDto.getConfirmPassword())) {
            return;
        }
        Set<ConstraintViolation<UserRegisterDto>> violations = this.validationUtil.violation(userRegisterDto);
        if (!violations.isEmpty()) {
            violations.stream()
                    .map(ConstraintViolation::getMessage)
                    .forEach(System.out::println);
        }
        User user = this.modelMapper.map(userRegisterDto, User.class);
        this.userRepository.save(user);
    }

    @Override
    public void loginUser(UserLoginDto userLoginDto) {
        User user = this.userRepository.findFirstByEmailAndPassword(userLoginDto.getEmail(), userLoginDto.getPassword());
        if (null == user) {
            System.out.println("User with this email / password doesn't exist!");
            return;
        }
        System.out.println("Successfully logged in as user: " + user.getFullName() + "!");
        this.loggedInUser = user;
        this.gameServiceImpl.setLoggedInUser(user);
    }

    @Override
    public void logout() {
        if (null == loggedInUser) {
            System.out.println("Cannot log out! No user was logged in.");
        }else {
            System.out.printf("User %s successfully logged out%n", loggedInUser.getFullName());
            this.loggedInUser = null;
            this.gameServiceImpl.setLoggedInUser(null);
        }
    }
}
