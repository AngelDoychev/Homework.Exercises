package com.example.springdataautomappingobjectsexercise.models.dto;

import jakarta.validation.constraints.Positive;

import java.math.BigDecimal;

public class GameUpdateDto {
    @Positive
    private BigDecimal price;
    @Positive
    private Double size;

    public GameUpdateDto() {
    }

    public GameUpdateDto(BigDecimal price, Double size) {
        this.price = price;
        this.size = size;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public Double getSize() {
        return size;
    }

    public void setSize(Double size) {
        this.size = size;
    }
}
