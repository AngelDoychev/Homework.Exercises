package com.example.springdataautomappingobjectsexercise.services;

import com.example.springdataautomappingobjectsexercise.models.dto.UserLoginDto;
import com.example.springdataautomappingobjectsexercise.models.dto.UserRegisterDto;
import com.example.springdataautomappingobjectsexercise.models.entities.User;

public interface UserService {

    void registerUser(UserRegisterDto userRegisterDto);

    void loginUser(UserLoginDto userLoginDto);

    void logout();
}
