package com.example.springdataautomappingobjectsexercise.services.implementations;

import com.example.springdataautomappingobjectsexercise.models.dto.GameAddDto;
import com.example.springdataautomappingobjectsexercise.models.dto.GamePrintAllDto;
import com.example.springdataautomappingobjectsexercise.models.dto.GamePrintDetailsDto;
import com.example.springdataautomappingobjectsexercise.models.dto.GameUpdateDto;
import com.example.springdataautomappingobjectsexercise.models.entities.Game;
import com.example.springdataautomappingobjectsexercise.models.entities.User;
import com.example.springdataautomappingobjectsexercise.repositories.GameRepository;
import com.example.springdataautomappingobjectsexercise.services.GameService;
import com.example.springdataautomappingobjectsexercise.util.ValidationUtil;
import jakarta.validation.ConstraintViolation;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Set;

@Service
public class GameServiceImpl implements GameService {
    private final GameRepository gameRepository;
    private final ModelMapper modelMapper;
    private final ValidationUtil validationUtil;
    private User loggedInUser;

    public GameServiceImpl(GameRepository gameRepository, ModelMapper modelMapper, ValidationUtil validationUtil) {
        this.gameRepository = gameRepository;
        this.modelMapper = modelMapper;
        this.validationUtil = validationUtil;
    }

    @Override
    public void addGame(GameAddDto gameAddDto) {
        if (!this.loggedInUser.isAdmin()) {
            return;
        }
        Set<ConstraintViolation<GameAddDto>> violations = this.validationUtil.violation(gameAddDto);
        if (!violations.isEmpty()) {
            violations.stream()
                    .map(ConstraintViolation::getMessage)
                    .forEach(System.out::println);
        }
        Game game = this.modelMapper.map(gameAddDto, Game.class);
        this.gameRepository.save(game);
        System.out.println("Added " + game.getTitle());
    }

    @Override
    @Transactional
    public void editGame(long id, GameUpdateDto gameUpdateDto) {
        if (!this.loggedInUser.isAdmin()) {
            return;
        }
        Set<ConstraintViolation<GameUpdateDto>> violations = this.validationUtil.violation(gameUpdateDto);
        if (!violations.isEmpty()) {
            violations.stream()
                    .map(ConstraintViolation::getMessage)
                    .forEach(System.out::println);
        }
        this.gameRepository.updateGamePriceAndSizeById(id, gameUpdateDto.getPrice(), gameUpdateDto.getSize());
        System.out.println("Edited game: " + this.gameRepository.findById(id).stream().findFirst().map(Game::getTitle).orElse(null));
    }

    @Override
    @Transactional
    public void deleteGameById(long id) {
        if (!this.loggedInUser.isAdmin()) {
            return;
        }
        System.out.println("Deleted game: " + this.gameRepository.findById(id).stream().findFirst().map(Game::getTitle).orElse(null));
        this.gameRepository.removeAllById(id);
    }

    @Override
    public void printAllGames() {
        this.gameRepository
                .findAll()
                .stream()
                .map(game -> this.modelMapper.map(game, GamePrintAllDto.class))
                .forEach(gameDto -> System.out.printf("%s %.2f%n", gameDto.getTitle(), gameDto.getPrice()));
    }

    @Override
    public void printDetailsForGame(String title) {
        Game game = this.gameRepository.findFirstByTitle(title);
        GamePrintDetailsDto gameDto = this.modelMapper.map(game, GamePrintDetailsDto.class);
        System.out.printf("Title: %s%nPrice: %.2f%nDescription: %s%nRelease date: %s%n",
                gameDto.getTitle(),
                gameDto.getPrice(),
                gameDto.getDescription(),
                gameDto.getReleaseDAte());
    }

    public void setLoggedInUser(User loggedInUser) {
        this.loggedInUser = loggedInUser;
    }
}
