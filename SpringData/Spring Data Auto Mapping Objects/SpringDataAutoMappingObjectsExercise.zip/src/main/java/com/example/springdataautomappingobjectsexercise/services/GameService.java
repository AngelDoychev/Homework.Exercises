package com.example.springdataautomappingobjectsexercise.services;

import com.example.springdataautomappingobjectsexercise.models.dto.GameAddDto;
import com.example.springdataautomappingobjectsexercise.models.dto.GameUpdateDto;

import java.math.BigDecimal;

public interface GameService {
    void addGame(GameAddDto gameAddDto);

    void editGame(long id, GameUpdateDto gameUpdateDto);

    void deleteGameById(long id);

    void printAllGames();

    void printDetailsForGame(String title);
}
