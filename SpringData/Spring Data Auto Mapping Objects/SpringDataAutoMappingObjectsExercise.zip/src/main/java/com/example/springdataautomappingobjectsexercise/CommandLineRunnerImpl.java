package com.example.springdataautomappingobjectsexercise;

import com.example.springdataautomappingobjectsexercise.models.dto.GameAddDto;
import com.example.springdataautomappingobjectsexercise.models.dto.GameUpdateDto;
import com.example.springdataautomappingobjectsexercise.models.dto.UserLoginDto;
import com.example.springdataautomappingobjectsexercise.models.dto.UserRegisterDto;
import com.example.springdataautomappingobjectsexercise.services.GameService;
import com.example.springdataautomappingobjectsexercise.services.UserService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

@Component
public class CommandLineRunnerImpl implements CommandLineRunner {
    private final Scanner scanner;
    private final UserService userService;
    private final GameService gameService;

    public CommandLineRunnerImpl(UserService userService, GameService gameService) {
        this.userService = userService;
        this.gameService = gameService;
        scanner = new Scanner(System.in);
    }

    @Override
    public void run(String... args) throws Exception {
        for (; ; ) {
            System.out.println("Please type a command!");
            String[] commands = this.scanner.nextLine().split("\\|");
            switch (commands[0]) {
                case "RegisterUser" -> registerUser(commands[1], commands[2], commands[3], commands[4]);
                case "LoginUser" -> loginUser(commands[1], commands[2]);
                case "Logout" -> logout();
                case "AddGame" -> addGame(commands[1], new BigDecimal(commands[2]), Double.parseDouble(commands[3]),
                        commands[4], commands[5], commands[6], LocalDate.parse(commands[7], DateTimeFormatter.ofPattern("dd-MM-yyyy")));
                case "EditGame" -> editGame(Long.parseLong(commands[1]),
                        new BigDecimal(commands[2].replaceAll("[^0-9.]*", "")),
                        Double.parseDouble(commands[3].replaceAll("[^0-9.]*", "")));
                case "DeleteGame" -> deleteGame(Long.parseLong(commands[1]));
                case "AllGames" -> printAllGames();
                case "DetailGame" -> printDetailsForGame(commands[1]);
            }
        }
    }

    private void printDetailsForGame(String title) {
        this.gameService.printDetailsForGame(title);
    }

    private void printAllGames() {
        this.gameService.printAllGames();
    }

    private void deleteGame(long id) {
        this.gameService.deleteGameById(id);
    }

    private void editGame(long id, BigDecimal price, double size) {
        this.gameService.editGame(id, new GameUpdateDto(price, size));
    }

    private void addGame(String title, BigDecimal price, double size, String trailerUrl, String imageUrl, String description, LocalDate releaseDate) {
        this.gameService.addGame(new GameAddDto(title, price, size, trailerUrl, imageUrl, description, releaseDate));
    }

    private void logout() {
        this.userService.logout();
    }

    private void loginUser(String email, String password) {
        this.userService.loginUser(new UserLoginDto(email, password));
    }

    private void registerUser(String email, String password, String confirmPassword, String fullName) {
        this.userService.registerUser(new UserRegisterDto(email, password, confirmPassword, fullName));
    }
}
