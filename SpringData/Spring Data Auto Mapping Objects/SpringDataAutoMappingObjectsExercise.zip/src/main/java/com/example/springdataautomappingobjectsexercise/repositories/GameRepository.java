package com.example.springdataautomappingobjectsexercise.repositories;

import com.example.springdataautomappingobjectsexercise.models.entities.Game;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

@Repository
public interface GameRepository extends JpaRepository<Game, Long> {
    @Query("UPDATE Game g SET g.price = :price, g.size = :size WHERE g.id = :id")
    @Modifying
    void updateGamePriceAndSizeById(@Param(value = "id") Long id,
                                    @Param(value = "price") BigDecimal price,
                                    @Param(value = "size") Double size);
    @Modifying
    void removeAllById(long id);
    Game findFirstByTitle(String title);
}
