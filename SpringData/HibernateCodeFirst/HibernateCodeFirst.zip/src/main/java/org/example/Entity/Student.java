package org.example.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import java.util.Set;

@Entity
@Table(name = "students")
public class Student extends User {
    @Column(name = "average_grade")
    private double averageGrade;
    @Column(name = "attendance", precision = 1, scale = 2)
    private String attendance;

    @ManyToMany(mappedBy = "students")
    private Set<Course> courses;
    public Student() {
    }


    public double getAverageGrade() {
        return averageGrade;
    }

    public void setAverageGrade(double averageGrade) {
        this.averageGrade = averageGrade;
    }

    public String getAttendance() {
        return attendance;
    }

    public void setAttendance(String attendance) {
        this.attendance = attendance;
    }
}
