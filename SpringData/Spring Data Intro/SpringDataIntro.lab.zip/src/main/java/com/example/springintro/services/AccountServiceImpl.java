package com.example.springintro.services;

import com.example.springintro.models.Account;
import com.example.springintro.repositories.AccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
public class AccountServiceImpl implements AccountService {
    private final AccountRepository accountRepository;

    public AccountServiceImpl(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    @Override
    public void withdrawMoney(BigDecimal amount, long id) {
        Account account = this.accountRepository.findById(id).orElseThrow();
        if (account.getBalance().compareTo(amount) < 0) {
            throw new IllegalArgumentException();
        }
        account.setBalance(account.getBalance().subtract(amount));
        this.accountRepository.save(account);
    }

    @Override
    public void transferMoney(BigDecimal amount, long id) {
        Account account = this.accountRepository.findById(id).orElseThrow();
        account.setBalance(account.getBalance().add(amount));
        this.accountRepository.save(account);
    }
}
