package com.example.springintro;

import com.example.springintro.services.AccountService;
import com.example.springintro.services.UserService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
public class ConsoleRunner implements CommandLineRunner {
    private final UserService userService;
    private final AccountService accountService;

    public ConsoleRunner(UserService userService, AccountService accountService) {
        this.userService = userService;
        this.accountService = accountService;
    }


    @Override
    public void run(String... args) throws Exception {
       // this.userService.register("Angel", 24, BigDecimal.valueOf(285));
        try{
            this.accountService.withdrawMoney(new BigDecimal(100), 1L);
        }catch (IllegalArgumentException e) {

        }
    }
}
