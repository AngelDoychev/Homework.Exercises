package com.example.springdataintroexercise.model.entity;

public enum EditionType {
    NORMAL, PROMO, GOLD
}
