package com.example.springdataintroexercise.service;

import com.example.springdataintroexercise.model.entity.Category;
import com.example.springdataintroexercise.repository.CategoryRepository;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

@Service
public class CategoryServiceImpl implements CategoryService {
    private final CategoryRepository categoryRepository;
    private static final String CATEGORIES_PATH = "src/main/resources/files/categories.txt";

    public CategoryServiceImpl(CategoryRepository categoryRepository) {
        this.categoryRepository = categoryRepository;
    }

    @Override
    public void seedCategories() throws IOException {
        if (this.categoryRepository.count() > 0) {
            return;
        }
        Files.readAllLines(Path.of(CATEGORIES_PATH))
                .stream()
                .filter(category -> !category.isEmpty())
                .forEach(name -> {
                    Category category = new Category(name);
                    this.categoryRepository.save(category);
                });

    }

    @Override
    public Set<Category> getRandomCategories() {
        Set<Category> categories = new HashSet<>();
        int randomNum = ThreadLocalRandom.current().nextInt(1, 3);
        for (int i = 0; i < randomNum; i++) {
            long randomId = ThreadLocalRandom.current().nextLong(1, this.categoryRepository.count() + 1);
            Category category = this.categoryRepository.findById(randomId).orElse(null);
            categories.add(category);
        }
        return categories;
    }
}
