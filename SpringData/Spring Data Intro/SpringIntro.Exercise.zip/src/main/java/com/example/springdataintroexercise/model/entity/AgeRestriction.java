package com.example.springdataintroexercise.model.entity;

public enum AgeRestriction {
    MINOR, TEEN, ADULT
}
