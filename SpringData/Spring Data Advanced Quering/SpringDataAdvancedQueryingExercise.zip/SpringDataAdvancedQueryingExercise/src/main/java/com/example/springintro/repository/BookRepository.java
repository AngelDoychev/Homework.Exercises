package com.example.springintro.repository;

import com.example.springintro.model.entity.AgeRestriction;
import com.example.springintro.model.entity.Book;
import com.example.springintro.model.entity.EditionType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Repository
public interface BookRepository extends JpaRepository<Book, Long> {

    List<Book> findAllByReleaseDateAfter(LocalDate releaseDateAfter);

    List<Book> findAllByReleaseDateBefore(LocalDate releaseDateBefore);

    List<Book> findAllByAuthor_FirstNameAndAuthor_LastNameOrderByReleaseDateDescTitle(String author_firstName, String author_lastName);

    List<Book> findAllByAgeRestriction(AgeRestriction ageRestriction);

    List<Book> findAllByEditionTypeAndCopiesLessThan(EditionType editionType, Integer copies);

    List<Book> findAllByPriceLessThanOrPriceGreaterThan(BigDecimal lowerThan, BigDecimal greaterThan);

    List<Book> findAllByReleaseDateBeforeOrReleaseDateAfter(LocalDate releaseDate, LocalDate releaseDate2);

    List<Book> findAllByTitleContaining(String containingStr);

    List<Book> findAllByAuthor_LastNameStartingWith(String startingStr);

    @Query("SELECT count(b) FROM Book b WHERE length(b.title) > :titleCount")
    int countAllByTitleCountIsMoreThan(@Param(value = "titleCount") int titleCount);

    Book findFirstByTitle(String title);

    @Query("UPDATE FROM Book b SET b.copies = b.copies + :number WHERE b.releaseDate > :date")
    @Modifying
    int increaseBookCopiesOfBooksReleasedAfterWithGivenNumber(int number,
                                                               @Param(value = "date") LocalDate date
    );
    @Modifying
    int removeAllByCopiesLessThan(Integer copies);
    @Query(value = "CALL get_books_by_author_name(:firstName, :lastName)", nativeQuery = true)
    int BookCountByAuthorFirstNameAndLastName(@Param(value = "firstName") String firstName,
                                              @Param(value = "lastName") String lastName);
}
