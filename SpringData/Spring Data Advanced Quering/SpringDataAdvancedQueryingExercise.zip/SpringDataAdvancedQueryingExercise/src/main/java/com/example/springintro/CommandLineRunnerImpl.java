package com.example.springintro;

import com.example.springintro.model.entity.AgeRestriction;
import com.example.springintro.model.entity.Book;
import com.example.springintro.model.entity.EditionType;
import com.example.springintro.service.AuthorService;
import com.example.springintro.service.BookService;
import com.example.springintro.service.CategoryService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

@Component
public class CommandLineRunnerImpl implements CommandLineRunner {

    private final CategoryService categoryService;
    private final AuthorService authorService;
    private final BookService bookService;

    public CommandLineRunnerImpl(CategoryService categoryService, AuthorService authorService, BookService bookService) {
        this.categoryService = categoryService;
        this.authorService = authorService;
        this.bookService = bookService;
    }

    @Override
    public void run(String... args) throws Exception {
        seedData();

        // printAllBooksAfterYear(2000);
// printAllAuthorsNamesWithBooksWithReleaseDateBeforeYear(1990);
        // printAllAuthorsAndNumberOfTheirBooks();
        // pritnALlBooksByAuthorNameOrderByReleaseDate("George", "Powell");

        Scanner scanner = new Scanner(System.in);
        System.out.println("Please select exercise number!");
        int exerciseNumber = Integer.parseInt(scanner.nextLine());
        switch (exerciseNumber) {
            case 1 -> exercise1();
            case 2 -> exercise2();
            case 3 -> exercise3();
            case 4 -> exercise4();
            case 5 -> exercise5();
            case 6 -> exercise6();
            case 7 -> exercise7();
            case 8 -> exercise8();
            case 9 -> exercise9();
            case 10 -> exercise10();
            case 11 -> exercise11();
            case 12 -> exercise12();
            case 13 -> exercise13();
            case 14 -> exercise14();
        }
    }

    private void exercise14() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please select the full name of the author!");
        String[] name = scanner.nextLine().split("\\s+");
        String firstName = name[0];
        String lastName = name[1];
        System.out.println(this.bookService.bookCountByAuthorFirstNameAndLastName(firstName, lastName));
    }

    private void exercise13() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please select the number of copies!");
        int copies = Integer.parseInt(scanner.nextLine());
        System.out.println(this.bookService.removeAllByCopiesLessThan(copies));
    }

    private void exercise12() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please select number of copies to increase!");
        int copies = Integer.parseInt(scanner.nextLine());
        System.out.println("Please select title!");
        LocalDate date = LocalDate.parse(scanner.nextLine(), DateTimeFormatter.ofPattern("dd MMM yyyy"));
        System.out.println(copies * this.bookService.increaseBookCopiesOfBooksReleasedAfterWithGivenNumber(copies, date));
    }

    private void exercise11() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please select title!");
        String title = scanner.nextLine();
        Book book = this.bookService.findFirstByTitle(title);
        System.out.printf("%s %s %s %.2f%n"
                , book.getTitle()
                , book.getEditionType().name()
                , book.getAgeRestriction().name()
                , book.getPrice());
    }

    private void exercise10() {
        this.authorService
                .findAllByBookCopiesSold()
                .forEach(System.out::println);
    }

    private void exercise9() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please select title count!");
        int titleCount = Integer.parseInt(scanner.nextLine());
        System.out.println(this.bookService.countAllByTitleCountIsMoreThan(titleCount));
    }

    private void exercise8() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please select starting string of last name of author!");
        String startingStr = scanner.nextLine();
        this.bookService.findAllByAuthor_LastNameStartingWith(startingStr)
                .stream()
                .map(book -> String.format("%s (%s %s)"
                        , book.getTitle()
                        , book.getAuthor().getFirstName()
                        , book.getAuthor().getLastName()))
                .forEach(System.out::println);
    }

    private void exercise7() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please select contained string of title!");
        String containingStr = scanner.nextLine();
        this.bookService.findAllByTitleContaining(containingStr)
                .forEach(book -> System.out.println(book.getTitle()));
    }

    private void exercise6() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please select ending string of first name!");
        String endStr = scanner.nextLine();
        this.authorService.findAllByFirstNameEndingWith(endStr)
                .stream()
                .map(author -> String.format("%s %s", author.getFirstName(), author.getLastName()))
                .forEach(System.out::println);
    }

    private void exercise5() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please select date!");
        LocalDate date = LocalDate.parse(scanner.nextLine(), DateTimeFormatter.ofPattern("dd-MM-yyyy"));
        this.bookService.findAllByReleaseDateBefore(date)
                .stream()
                .map(book -> String.format("%s %s %.2f", book.getTitle(), book.getEditionType().name(), book.getPrice()))
                .forEach(System.out::println);
    }

    private void exercise4() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please select year!");
        int year = Integer.parseInt(scanner.nextLine());
        LocalDate before = LocalDate.of(year, 1, 1);
        LocalDate after = LocalDate.of(year, 12, 31);
        this.bookService.findAllByReleaseDateBeforeOrReleaseDateAfter(before, after)
                .stream()
                .map(Book::getTitle)
                .forEach(System.out::println);
    }

    private void exercise3() {
        this.bookService.findAllByPriceLessThanOrPriceGreaterThan(new BigDecimal("5"), new BigDecimal("40"))
                .stream()
                .map(book -> String.format("%s - $%.2f", book.getTitle(), book.getPrice()))
                .forEach(System.out::println);
    }

    private void exercise2() {
        this.bookService.findAllByEditionTypeAndCopiesLessThan(EditionType.GOLD, 5000)
                .stream()
                .map(Book::getTitle)
                .forEach(System.out::println);
    }

    private void exercise1() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please select age restriction!");
        String ageRestrictionName = scanner.nextLine();
        AgeRestriction ageRestriction = AgeRestriction.valueOf(ageRestrictionName.toUpperCase());
        this.bookService.findAllByAgeRestriction(ageRestriction)
                .stream()
                .map(Book::getTitle)
                .forEach(System.out::println);
    }

    private void pritnALlBooksByAuthorNameOrderByReleaseDate(String firstName, String lastName) {
        bookService
                .findAllBooksByAuthorFirstAndLastNameOrderByReleaseDate(firstName, lastName)
                .forEach(System.out::println);
    }

    private void printAllAuthorsAndNumberOfTheirBooks() {
        authorService
                .getAllAuthorsOrderByCountOfTheirBooks()
                .forEach(System.out::println);
    }

    private void printAllAuthorsNamesWithBooksWithReleaseDateBeforeYear(int year) {
        bookService
                .findAllAuthorsWithBooksWithReleaseDateBeforeYear(year)
                .forEach(System.out::println);
    }

    private void printAllBooksAfterYear(int year) {
        bookService
                .findAllBooksAfterYear(year)
                .stream()
                .map(Book::getTitle)
                .forEach(System.out::println);
    }

    private void seedData() throws IOException {
        categoryService.seedCategories();
        authorService.seedAuthors();
        bookService.seedBooks();
    }
}
