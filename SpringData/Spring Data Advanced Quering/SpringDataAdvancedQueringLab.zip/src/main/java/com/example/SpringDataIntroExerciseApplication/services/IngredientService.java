package com.example.SpringDataIntroExerciseApplication.services;

import com.example.SpringDataIntroExerciseApplication.entities.Ingredient;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.List;

public interface IngredientService {
    List<Ingredient> findAllByNameStartingWith(String name);
    List<Ingredient> findAllByNameIn(Collection<String> name);
    void deleteAllByName(String name);
    void updatePrice(BigDecimal percent);
    void updatePrice(BigDecimal percent, Collection<String> names);
}
