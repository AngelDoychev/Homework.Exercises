package com.example.SpringDataIntroExerciseApplication.services;

public interface LabelService {

}
