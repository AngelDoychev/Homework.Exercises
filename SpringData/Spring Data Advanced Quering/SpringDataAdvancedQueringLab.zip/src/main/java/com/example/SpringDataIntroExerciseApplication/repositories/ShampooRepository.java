package com.example.SpringDataIntroExerciseApplication.repositories;

import com.example.SpringDataIntroExerciseApplication.entities.Shampoo;
import com.example.SpringDataIntroExerciseApplication.entities.Size;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Repository
public interface ShampooRepository extends JpaRepository<Shampoo, Long> {
    List<Shampoo> findAllBySizeOrderById(Size size);
    List<Shampoo> findAllBySizeOrLabelIdOrderByPrice(Size size, Long label);
    List<Shampoo> findAllByPriceGreaterThanOrderByPriceDesc(BigDecimal price);
    List<Shampoo> findAllByPriceLessThan(BigDecimal price);
    @Query("SELECT s FROM Shampoo s JOIN s.ingredients i WHERE i.name IN :ingredients")
    List<Shampoo> findAllByMultipleIngredients(List<String> ingredients);
    @Query("SELECT s FROM Shampoo s JOIN s.ingredients i GROUP BY s.id HAVING count(i) < :ingredientsCount")
    List<Shampoo> findAllByIngredientCounts(int ingredientsCount);
}
