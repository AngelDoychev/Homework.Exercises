package com.example.SpringDataIntroExerciseApplication;

import com.example.SpringDataIntroExerciseApplication.entities.Shampoo;
import com.example.SpringDataIntroExerciseApplication.entities.Size;
import com.example.SpringDataIntroExerciseApplication.services.IngredientService;
import com.example.SpringDataIntroExerciseApplication.services.ShampooService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
@Component
public class ApplicationStarter implements CommandLineRunner {
    private final ShampooService shampooService;
    private final IngredientService ingredientService;

    public ApplicationStarter(ShampooService shampooService, IngredientService ingredientService) {
        this.shampooService = shampooService;
        this.ingredientService = ingredientService;
    }

    @Override
    public void run(String... args) throws Exception {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please choose exercise number!");
        String exercise = scanner.nextLine();
        switch (Integer.parseInt(exercise)) {
            case 1 -> exercise1();
            case 2 -> exercise2();
            case 3 -> exercise3();
            case 4 -> exercise4();
            case 5 -> exercise5();
            case 6 -> exercise6();
            case 7 -> exercise7();
            case 8 -> exercise8();
            case 9 -> exercise9();
            case 10 -> exercise10();
            case 11 -> exercise11();
        }
    }

    private void exercise11() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please select percent!");
        String percent = scanner.nextLine();
        System.out.println("Please select name!");
        List<String> names = Arrays.asList(scanner.nextLine().split("\\s+"));
        this.ingredientService.updatePrice(new BigDecimal(percent), names);
        System.out.println("Update successful!");
    }

    private void exercise10() {
        this.ingredientService.updatePrice(new BigDecimal("1.1"));
        System.out.println("Update successful!");
    }

    private void exercise9() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please select an ingredient you wish to delete!");
        String name = scanner.nextLine();
        this.ingredientService.deleteAllByName(name);
    }

    private void exercise8() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please select count of ingredients!");
        int ingredientsCount = Integer.parseInt(scanner.nextLine());
        this.shampooService.findAllByIngredientCounts(ingredientsCount).stream().map(Shampoo::getBrand).forEach(System.out::println);
    }

    private void exercise7() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please select ingredients!");
        List<String> ingredients = Arrays.asList(scanner.nextLine().split("\\s+"));
        this.shampooService.findAllByMultipleIngredients(ingredients).stream().map(Shampoo::getBrand).forEach(System.out::println);
    }

    private void exercise6() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please select price");
        String price = scanner.nextLine();
        System.out.println(this.shampooService.findAllByPriceLessThan(new BigDecimal(price)).size());
    }

    private void exercise5() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please select ingredients!");
        List<String> ingredients = Arrays.asList(scanner.nextLine().split("\\s+"));
        this.ingredientService.findAllByNameIn(ingredients).forEach(System.out::println);
    }

    private void exercise4() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please select part of name!");
        String name = scanner.nextLine();
        this.ingredientService.findAllByNameStartingWith(name).forEach(System.out::println);
    }

    private void exercise3() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please select price!");
        String price = scanner.nextLine();
        this.shampooService.findAllByPriceGreaterThanOrderByPriceDesc(new BigDecimal(price)).forEach(System.out::println);

    }

    private void exercise2() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please input size!");
        String sizeInput = scanner.nextLine();
        Size size = Size.valueOf(sizeInput);
        System.out.println("Please input label ID!");
        Long labelId = Long.parseLong(scanner.nextLine());
        this.shampooService.findAllBySizeOrLabelIdOrderByPrice(size , labelId).forEach(System.out::println);
    }

    private void exercise1() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please input size!");
        String sizeInput = scanner.nextLine();
        Size size = Size.valueOf(sizeInput);
        this.shampooService.findAllBySizeOrderById(size).forEach(System.out::println);
    }
}
