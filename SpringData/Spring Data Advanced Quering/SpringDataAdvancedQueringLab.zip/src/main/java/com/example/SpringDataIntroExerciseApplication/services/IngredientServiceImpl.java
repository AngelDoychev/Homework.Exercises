package com.example.SpringDataIntroExerciseApplication.services;

import com.example.SpringDataIntroExerciseApplication.entities.Ingredient;
import com.example.SpringDataIntroExerciseApplication.repositories.IngredientRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.List;
@Service
public class IngredientServiceImpl implements IngredientService{
    private final IngredientRepository ingredientRepository;

    public IngredientServiceImpl(IngredientRepository ingredientRepository) {
        this.ingredientRepository = ingredientRepository;
    }

    @Override
    public List<Ingredient> findAllByNameStartingWith(String name) {
        return this.ingredientRepository.findAllByNameStartingWith(name);
    }

    @Override
    public List<Ingredient> findAllByNameIn(Collection<String> name) {
        return this.ingredientRepository.findAllByNameIn(name);
    }

    @Override
    @Transactional
    public void deleteAllByName(String name) {
        this.ingredientRepository.deleteAllByName(name);
    }

    @Override
    @Transactional
    public void updatePrice(BigDecimal percent) {
        this.ingredientRepository.updatePrice(percent);
    }

    @Override
    @Transactional
    public void updatePrice(BigDecimal percent, Collection<String> names) {
        this.ingredientRepository.updatePrice(percent, names);
    }
}
