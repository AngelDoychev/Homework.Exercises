package com.example.SpringDataIntroExerciseApplication.services;

import com.example.SpringDataIntroExerciseApplication.entities.Shampoo;
import com.example.SpringDataIntroExerciseApplication.entities.Size;
import com.example.SpringDataIntroExerciseApplication.repositories.ShampooRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
public class ShampooServiceImpl implements ShampooService {

    private final ShampooRepository shampooRepository;

    public ShampooServiceImpl(ShampooRepository shampooRepository) {
        this.shampooRepository = shampooRepository;
    }

    @Override
    public List<Shampoo> findAllBySizeOrderById(Size size) {
        return this.shampooRepository.findAllBySizeOrderById(size);
    }

    @Override
    public List<Shampoo> findAllBySizeOrLabelIdOrderByPrice(Size size, Long label) {
        return this.shampooRepository.findAllBySizeOrLabelIdOrderByPrice(size, label);
    }

    @Override
    public List<Shampoo> findAllByPriceGreaterThanOrderByPriceDesc(BigDecimal price) {
        return this.shampooRepository.findAllByPriceGreaterThanOrderByPriceDesc(price);
    }

    @Override
    public List<Shampoo> findAllByPriceLessThan(BigDecimal price) {
        return this.shampooRepository.findAllByPriceLessThan(price);
    }

    @Override
    public List<Shampoo> findAllByMultipleIngredients(List<String> ingredients) {
        return this.shampooRepository.findAllByMultipleIngredients(ingredients);
    }

    @Override
    public List<Shampoo> findAllByIngredientCounts(int ingredientsCount) {
        return this.shampooRepository.findAllByIngredientCounts(ingredientsCount);
    }
}
