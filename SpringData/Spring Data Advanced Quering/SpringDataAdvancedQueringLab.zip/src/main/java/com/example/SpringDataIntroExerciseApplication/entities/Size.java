package com.example.SpringDataIntroExerciseApplication.entities;
public enum Size {
    SMALL, MEDIUM, LARGE;
}
