package carShop;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class CarShopTests {

    @Test
    public void testGetCarsReturnsCollection(){
        CarShop carShop = new CarShop();
        Car car = new Car("car", 100, 120d);
        Car car2 = new Car("car2", 100, 120d);
        carShop.add(car);
        carShop.add(car2);
        List<Car> list = new ArrayList<>();
        list.add(car);
        list.add(car2);
        Assert.assertEquals(list, carShop.getCars());
    }
    @Test
    public void testGetCountReturnsTheNumberOfCarsInCollection(){
        CarShop carShop = new CarShop();
        Car car = new Car("car", 100, 120d);
        Assert.assertEquals(carShop.getCount(), 0);
        carShop.add(car);
        Assert.assertEquals(carShop.getCount(), 1);
    }
    @Test
    public void testAddCarAddsCarToCarShop(){
        CarShop carShop = new CarShop();
        Car car = new Car("car", 100, 120d);
        Assert.assertEquals(carShop.getCount(), 0);
        carShop.add(car);
        Assert.assertEquals(carShop.getCount(), 1);
    }
    @Test
    public void testFindAllCarsWithMaxHorsePowerShouldGiveOnlyCarsWithMoreHPThanGiven(){
        CarShop carShop = new CarShop();
        Car car = new Car("car", 100, 120d);
        Car car2 = new Car("car2", 20, 120d);
        carShop.add(car);
        carShop.add(car2);
        List<Car> list = new ArrayList<>();
        list.add(car);
        Assert.assertEquals(list, carShop.findAllCarsWithMaxHorsePower(99));
    }
    @Test(expected = NullPointerException.class)
    public void testAddShouldThrowIfCarIsNull(){
        CarShop carShop = new CarShop();
        Car car = null;
        carShop.add(car);
    }
    @Test
    public void testRemoveShouldRemoveCarFromCarShop(){
        CarShop carShop = new CarShop();
        Car car = new Car("car2", 20, 120d);
        carShop.add(car);
        Assert.assertEquals(1, carShop.getCount());
        carShop.remove(car);
        Assert.assertEquals(0, carShop.getCount());
    }
    @Test
    public void testGetTheMostLuxuryCarShouldReturnTheMostExpensiveCar(){
        CarShop carShop = new CarShop();
        Car car = new Car("car2", 20, 120d);
        Car car1 = new Car("car2", 20, 150d);
        Car car2 = new Car("car2", 20, 200d);
        carShop.add(car);
        carShop.add(car1);
        carShop.add(car2);
        Assert.assertEquals(car2, carShop.getTheMostLuxuryCar());
    }
    @Test
    public void testFindAllCarByModelShouldReturnAllCarsWithGivenModel(){
        CarShop carShop = new CarShop();
        Car car = new Car("model", 20, 120d);
        Car car1 = new Car("model", 20, 150d);
        Car car2 = new Car("notThatModel", 20, 200d);
        carShop.add(car);
        carShop.add(car1);
        carShop.add(car2);
        List<Car> expected = new ArrayList<>();
        expected.add(car);
        expected.add(car1);
        Assert.assertEquals(expected, carShop.findAllCarByModel("model"));
    }
}

