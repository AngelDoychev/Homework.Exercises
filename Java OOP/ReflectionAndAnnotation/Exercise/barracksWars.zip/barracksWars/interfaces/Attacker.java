package JavaOOP.Reflection.Exercise.barracksWars.interfaces;

public interface Attacker {
    
    int getAttackDamage();
}
