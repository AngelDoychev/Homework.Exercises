package JavaOOP.Reflection.Exercise.barracksWars.interfaces;

import barracksWars.interfaces.Attacker;
import barracksWars.interfaces.Destroyable;

public interface Unit extends Destroyable, Attacker {
}
