package JavaOOP.Reflection.Exercise.barracksWarsExtended;

import JavaOOP.Reflection.Exercise.barracksWarsExtended.core.Engine;
import JavaOOP.Reflection.Exercise.barracksWarsExtended.core.commands.CommandInterpreterImpl;
import JavaOOP.Reflection.Exercise.barracksWarsExtended.core.factories.UnitFactoryImpl;
import JavaOOP.Reflection.Exercise.barracksWarsExtended.data.UnitRepository;
import JavaOOP.Reflection.Exercise.barracksWarsExtended.interfaces.CommandInterpreter;
import JavaOOP.Reflection.Exercise.barracksWarsExtended.interfaces.Repository;
import JavaOOP.Reflection.Exercise.barracksWarsExtended.interfaces.Runnable;
import JavaOOP.Reflection.Exercise.barracksWarsExtended.interfaces.UnitFactory;

public class Main {

    public static void main(String[] args) {
        Repository repository = new UnitRepository();
        UnitFactory unitFactory = new UnitFactoryImpl();
        CommandInterpreter commandInterpreter = new CommandInterpreterImpl(repository, unitFactory);
        Runnable engine = new Engine(commandInterpreter);
        engine.run();
    }
}
