package JavaOOP.Reflection.Exercise.barracksWarsExtended.core.commands;

import JavaOOP.Reflection.Exercise.barracksWarsExtended.interfaces.Repository;
import JavaOOP.Reflection.Exercise.barracksWarsExtended.interfaces.UnitFactory;

public class FightCommand extends Command {
    public FightCommand(String[] data, Repository repository, UnitFactory unitFactory) {
        super(data, repository, unitFactory);
    }

    @Override
    public String execute() {
        return "fight";
    }
}
