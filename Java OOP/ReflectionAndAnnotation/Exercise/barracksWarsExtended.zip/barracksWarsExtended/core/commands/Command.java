package JavaOOP.Reflection.Exercise.barracksWarsExtended.core.commands;

import JavaOOP.Reflection.Exercise.barracksWarsExtended.interfaces.Executable;
import JavaOOP.Reflection.Exercise.barracksWarsExtended.interfaces.Repository;
import JavaOOP.Reflection.Exercise.barracksWarsExtended.interfaces.UnitFactory;

public abstract class Command implements Executable {
    private String[] data;
    private Repository repository;
    private UnitFactory unitFactory;

    public Command(String[] data, Repository repository, UnitFactory unitFactory) {
        this.data = data;
        this.repository = repository;
        this.unitFactory = unitFactory;
    }

    public String[] getData() {
        return data;
    }

    public Repository getRepository() {
        return repository;
    }

    public UnitFactory getUnitFactory() {
        return unitFactory;
    }
}
