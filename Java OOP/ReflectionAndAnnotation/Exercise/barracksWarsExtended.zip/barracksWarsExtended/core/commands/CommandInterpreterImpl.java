package JavaOOP.Reflection.Exercise.barracksWarsExtended.core.commands;

import JavaOOP.Reflection.Exercise.barracksWarsExtended.interfaces.CommandInterpreter;
import JavaOOP.Reflection.Exercise.barracksWarsExtended.interfaces.Executable;
import JavaOOP.Reflection.Exercise.barracksWarsExtended.interfaces.Repository;
import JavaOOP.Reflection.Exercise.barracksWarsExtended.interfaces.UnitFactory;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class CommandInterpreterImpl implements CommandInterpreter {
    public final static String COMMAND_PACKAGE = "barracksWars.core.commands.";
    private Repository repository;
    private UnitFactory unitFactory;

    public CommandInterpreterImpl(Repository repository, UnitFactory unitFactory) {
        this.repository = repository;
        this.unitFactory = unitFactory;
    }

    @Override
    public Executable interpretCommand(String[] data, String commandName) {
        String className = parseCommandNameToClassName(commandName);
        Executable command = null;
        try {
            Class clazz = Class.forName(className);
            Constructor<Command> constructor = clazz.getDeclaredConstructor(String[].class, Repository.class, UnitFactory.class);
            command = constructor.newInstance(data, repository, unitFactory);
        } catch (ClassNotFoundException | NoSuchMethodException | InstantiationException | IllegalAccessException |
                 InvocationTargetException e) {
            throw new RuntimeException(e);
        }
        return command;
    }

    private String parseCommandNameToClassName(String commandName) {
        return COMMAND_PACKAGE + commandName.substring(0, 1).toUpperCase() + commandName.substring(1) + "Command";
    }
}
