package JavaOOP.Reflection.Exercise.barracksWarsExtended.core.factories;

import JavaOOP.Reflection.Exercise.barracksWarsExtended.interfaces.Unit;
import JavaOOP.Reflection.Exercise.barracksWarsExtended.interfaces.UnitFactory;

import java.lang.reflect.Constructor;

public class UnitFactoryImpl implements UnitFactory {

    private static final String UNITS_PACKAGE_NAME =
            "barracksWars.models.units.";

    @Override
    public Unit createUnit(String unitType) {
        try {
            Class unitClass = Class.forName(UNITS_PACKAGE_NAME + unitType);
            Constructor<Unit> constructor = unitClass.getDeclaredConstructor();
            return constructor.newInstance();
        } catch (Exception ex) {
            System.out.printf(ex.getMessage());
        }
        return null;
    }
}
