package JavaOOP.Reflection.Exercise.barracksWarsExtended.interfaces;

public interface Attacker {
    
    int getAttackDamage();
}
