package JavaOOP.Reflection.Exercise.barracksWarsExtended.interfaces;

public interface Executable {

	String execute();

}
