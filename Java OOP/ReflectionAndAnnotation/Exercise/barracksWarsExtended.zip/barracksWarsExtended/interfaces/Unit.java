package JavaOOP.Reflection.Exercise.barracksWarsExtended.interfaces;

public interface Unit extends Destroyable, Attacker {
}
