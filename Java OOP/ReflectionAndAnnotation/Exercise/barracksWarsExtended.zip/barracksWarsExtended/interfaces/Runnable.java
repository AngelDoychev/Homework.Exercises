package JavaOOP.Reflection.Exercise.barracksWarsExtended.interfaces;

public interface Runnable {
	void run();
}
