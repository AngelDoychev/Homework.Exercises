package JavaOOP.Reflection.Exercise.barracksWarsExtended.interfaces;

public interface UnitFactory {

    Unit createUnit(String unitType);
}