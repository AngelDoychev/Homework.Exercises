package magicGame.models.magicians;

import magicGame.models.magics.Magic;

public class Wizard extends MagicianImpl {
    public Wizard(String username, int health, int protection, Magic magic) {
        super(username, health, protection, magic);
    }

    @Override
    public String toString() {
        return "Wizard: " + super.getUsername() +
                System.lineSeparator() +
                "Health: " +
                super.getHealth() +
                System.lineSeparator() +
                "Protection: " +
                super.getProtection() +
                System.lineSeparator() +
                "Magic: " +
                super.getMagic().getName() +
                System.lineSeparator();
    }
}
