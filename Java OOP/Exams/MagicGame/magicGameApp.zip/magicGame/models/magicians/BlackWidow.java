package magicGame.models.magicians;

import magicGame.models.magics.Magic;

public class BlackWidow extends MagicianImpl {
    public BlackWidow(String username, int health, int protection, Magic magic) {
        super(username, health, protection, magic);
    }

    @Override
    public String toString() {
        return "BlackWidow: " + super.getUsername() +
                System.lineSeparator() +
                "Health: " +
                super.getHealth() +
                System.lineSeparator() +
                "Protection: " +
                super.getProtection() +
                System.lineSeparator() +
                "Magic: " +
                super.getMagic().getName() +
                System.lineSeparator();
    }
}
