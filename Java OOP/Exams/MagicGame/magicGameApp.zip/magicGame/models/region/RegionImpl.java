package magicGame.models.region;

import magicGame.models.magicians.Magician;
import magicGame.models.magicians.Wizard;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

public class RegionImpl implements Region {
    @Override
    public String start(Collection<Magician> magicians) {
        List<Magician> wizards = magicians.stream()
                .filter(magician -> magician.getClass()
                        .getSimpleName().equals("Wizard"))
                .collect(Collectors.toList());
        List<Magician> blackWidows = magicians.stream()
                .filter(magician -> magician.getClass()
                        .getSimpleName().equals("BlackWidow"))
                .collect(Collectors.toList());
        int turn = 0;
        while (wizards.stream().filter(Magician::isAlive).findFirst().orElse(null) != null
                && blackWidows.stream().filter(Magician::isAlive).findFirst().orElse(null) != null) {
            if (turn % 2 == 0) {
                Magician currentWizard = wizards.stream().filter(Magician::isAlive).filter(this::hasEnoughToFire).findFirst().orElse(null);
                Magician currentBlackWidow = blackWidows.stream().filter(Magician::isAlive).findFirst().orElse(null);
                if (currentWizard != null && currentBlackWidow != null) {
                    int attack = currentWizard.getMagic().fire();
                    currentBlackWidow.takeDamage(attack);
                }
            } else {
                Magician currentWizard = wizards.stream().filter(Magician::isAlive).findFirst().orElse(null);
                Magician currentBlackWidow = blackWidows.stream().filter(Magician::isAlive).filter(this::hasEnoughToFire).findFirst().orElse(null);
                if (currentWizard != null && currentBlackWidow != null) {
                    int attack = currentBlackWidow.getMagic().fire();
                    currentWizard.takeDamage(attack);
                }
            }
            turn++;
        }
        if (wizards.stream().filter(Magician::isAlive).findAny().isEmpty()
                && blackWidows.stream().anyMatch(Magician::isAlive)) {
            return "Black widows win!";
        }
        return "Wizards win!";
    }
    public boolean hasEnoughToFire(Magician magician) {
        if (magician.getMagic().getClass().getSimpleName().equals("RedMagic")) {
            return magician.getMagic().getBulletsCount() >= 1;
        } else if (magician.getMagic().getClass().getSimpleName().equals("BlackMagic")) {
            return magician.getMagic().getBulletsCount() >= 10;
        }
        return false;
    }
}
