package magicGame;

import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

public class MagicianTest {
    @Test
    public void testGetUsernameReturnsTheUsername() {

        Magician magician = new Magician("Angel", 10);
        Assert.assertEquals("Angel", magician.getUsername());
    }

    @Test(expected = NullPointerException.class)
    public void testSetUsernameThrowsExceptionIfUsernameIsNull() {
        Magician magician = new Magician(null, 10);
    }

    @Test(expected = NullPointerException.class)
    public void testSetUsernameThrowsExceptionIfUsernameIsEmpty() {
        Magician magician = new Magician("   ", 10);
    }

    @Test
    public void testSetUsernameSetsUsernameToGivenString() {
        Magician magician = new Magician("temp", 10);
        Assert.assertEquals("temp", magician.getUsername());
    }
    @Test
    public void testGetHealthGivesYouTheHealthOfTheMagician() {
        Magician magician = new Magician("temp", 10);
        Assert.assertEquals(10, magician.getHealth());
    }
    @Test(expected = IllegalArgumentException.class)
    public void testSetHealthThrowsIfLessThan0(){
        Magician magician = new Magician("Angel", -1);
    }
    @Test
    public void testSetHealthSetsTheHealthOfTheMagician() {
        Magician magician = new Magician("temp", 10);
        Assert.assertEquals(10, magician.getHealth());
    }
    @Test
    public void testGetMagicsReturnsAUnmodifiableCollectionOfAllTheMagics(){
        Magician magician = new Magician("Angel", 10);
        Magic redMagic = new Magic("red", 1);
        Magic blackMagic = new Magic("black", 1);
        List<Magic> expected = new ArrayList<>();
        expected.add(redMagic);
        expected.add(blackMagic);
        magician.addMagic(redMagic);
        magician.addMagic(blackMagic);
        Assert.assertEquals(expected, magician.getMagics());
    }
    @Test(expected = IllegalStateException.class)
    public void testTakeDamageOnDeadMagicianThrowsException(){
        Magician magician = new Magician("angel", 0);
        magician.takeDamage(10);
    }
    @Test
    public void testTakeDamageRemovesDamageFromMagiciansHealth(){
        int damage = 5;
        Magician magician = new Magician("Angel", 10);
        magician.takeDamage(damage);
        Assert.assertEquals(10-damage, magician.getHealth());
    }
    @Test(expected = NullPointerException.class)
    public void testAddMagicThrowsIfMagicIsNull(){
        Magician magician = new Magician("Angel", 10);
        Magic magic = null;
        magician.addMagic(magic);
    }
    @Test
    public void testAddMagicAddsMagicToMagician(){
        Magician magician = new Magician("Angel", 10);
        Magic magic = new Magic("redMagic", 10);
        magician.addMagic(magic);
        Assert.assertEquals(magic, magician.getMagic("redMagic"));
    }
    @Test
    public void testRemoveMagicRemovesMagicFromMagician(){
        Magician magician = new Magician("Angel", 10);
        Magic magic = new Magic("redMagic", 10);
        magician.addMagic(magic);
        magician.removeMagic(magic);
        Assert.assertEquals(null, magician.getMagic("redMagic"));
    }
    @Test
    public void testGetMagicReturnNullIfNotInMagicianRepository(){
        Magician magician = new Magician("Angel", 10);
        Assert.assertEquals(null, magician.getMagic("redMagic"));
    }
    @Test
    public void testGetMagicReturnsMagicByGivenName(){
        Magician magician = new Magician("Angel", 10);
        Magic magic = new Magic("redMagic", 10);
        magician.addMagic(magic);
        Assert.assertEquals(magic.getName(), magician.getMagic("redMagic").getName());
    }
}