package robots;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class ServiceTest {
    @Test(expected = IllegalArgumentException.class)
    public void testAddShouldThrowIfThereIsNoSpaceInTheCollection() {
        Service fullService = new Service("full", 0);
        fullService.add(new Robot("Angel"));
    }

    @Test
    public void testAddShouldAddRobotInTheCollection() {
        Robot robot = new Robot("Angel");
        Service service = new Service("service", 1);
        service.add(robot);
        Assert.assertEquals(1, service.getCount());
    }

    @Test
    public void testSetNameSetsNameIfValid() {
        Service service = new Service("Angel", 1);
        Assert.assertEquals("Angel", service.getName());
    }

    @Test(expected = NullPointerException.class)
    public void testSetNameShouldThrowIfInvalid() {
        Service service = new Service(null, 1);
    }

    @Test
    public void testGetCapacityShouldReturnTheCapacity() {
        int capacity = 5;
        Service service = new Service("service", capacity);
        Assert.assertEquals(capacity, service.getCapacity());
    }
    @Test
    public void testGetNameShouldReturnTheName(){
        Service service = new Service("service", 1);
        assertEquals("service", service.getName());
    }

    @Test
    public void testSetCapacityShouldSetCapacity() {
        int capacity = 5;
        Service service = new Service("service", capacity);
        Assert.assertEquals(capacity, service.getCapacity());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testSetCapacityShouldThrowIfLessThan0() {
        Service service = new Service("service", -1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testRemoveShouldThrowIfRobotIsNotInService() {
        Service service = new Service("service", 1);
        service.remove("robot");
    }

    @Test
    public void testRemoveShouldRemoveRobotIfItIsAlreadyInService() {
        Service service = new Service("service", 1);
        Robot robot = new Robot("Angel");
        service.add(robot);
        service.remove("Angel");
        Assert.assertEquals(0, service.getCount());
    }
    @Test(expected = IllegalArgumentException.class)
    public void testForSaleShouldThrowIfRobotIsNotInService() {
        Service service = new Service("service", 1);
        service.forSale("robot");
    }
    @Test
    public void testForSalePutsRobotAtFalse(){
        Service service = new Service("service", 1);
        Robot robot = new Robot("Angel");
        service.add(robot);
        service.forSale("Angel");
        Assert.assertFalse(robot.isReadyForSale());
    }
    @Test
    public void testReportShouldGiveReportForRobotsInTheService(){
        Service service = new Service("service", 1);
        Robot robot = new Robot("Angel");
        service.add(robot);
        String result = "The robot Angel is in the service service!";
        Assert.assertEquals(result, service.report());
    }
    @Test(expected = NullPointerException.class)
    public void testSetNameOnWhitespaces(){
       Service service = new Service("      ", 10);
    }
}