package robotService.entities.services;

import robotService.entities.robot.Robot;

public class MainService extends BaseService {
    private static final int DEFAULT_CAPACITY = 30;

    public MainService(String name) {
        super(name, DEFAULT_CAPACITY);
    }

    @Override
    public String getStatistics() {
        if (getRobots().size() == 0) {
            return String.format("%s MainService:%nRobots: none%nSupplements: %d Hardness: %d%n"
                    , super.getName()
                    , super.getSupplements().size()
                    , super.sumHardness()).trim();
        } else {
            String[] robotNames = super.getRobots().stream().map(Robot::getName).toArray(String[]::new);
            return String.format("%s MainService:%nRobots: %s%nSupplements: %d Hardness: %d%n"
                    , super.getName()
                    , String.join(" ", robotNames)
                    , super.getSupplements().size()
                    , super.sumHardness()).trim();
        }
    }
}
