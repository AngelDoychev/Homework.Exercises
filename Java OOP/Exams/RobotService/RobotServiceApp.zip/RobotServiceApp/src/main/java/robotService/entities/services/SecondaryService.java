package robotService.entities.services;

import robotService.entities.robot.Robot;

public class SecondaryService extends BaseService {
    private static final int DEFAULT_CAPACITY = 15;

    public SecondaryService(String name) {
        super(name, DEFAULT_CAPACITY);
    }

    @Override
    public String getStatistics() {
        if (getRobots().size() == 0) {
            return String.format("%s SecondaryService:%nRobots: none%nSupplements: %d Hardness: %d%n"
                    , super.getName()
                    , super.getSupplements().stream().count()
                    , super.sumHardness()).trim();
        } else {
            String[] robotNames = super.getRobots().stream().map(Robot::getName).toArray(String[]::new);
            return String.format("%s SecondaryService:%nRobots: %s%nSupplements: %d Hardness: %d%n"
                    , super.getName()
                    , String.join(" ", robotNames)
                    , super.getSupplements().stream().count()
                    , super.sumHardness()).trim();
        }
    }
}
