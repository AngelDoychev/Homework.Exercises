package robotService.core;

import robotService.Main;
import robotService.common.ConstantMessages;
import robotService.common.ExceptionMessages;
import robotService.entities.robot.FemaleRobot;
import robotService.entities.robot.MaleRobot;
import robotService.entities.robot.Robot;
import robotService.entities.services.MainService;
import robotService.entities.services.SecondaryService;
import robotService.entities.services.Service;
import robotService.entities.supplements.MetalArmor;
import robotService.entities.supplements.PlasticArmor;
import robotService.entities.supplements.Supplement;
import robotService.repositories.SupplementRepository;

import java.util.ArrayList;
import java.util.Collection;
import java.util.stream.Collectors;

public class ControllerImpl implements Controller {
    private SupplementRepository supplements;
    private Collection<Service> services;

    public ControllerImpl() {
        supplements = new SupplementRepository();
        this.services = new ArrayList<>();
    }

    @Override
    public String addService(String type, String name) {
        Service service = null;
        switch (type) {
            case "MainService":
                service = new MainService(name);
                break;
            case "SecondaryService":
                service = new SecondaryService(name);
                break;
            default:
                throw new NullPointerException(ExceptionMessages.INVALID_SERVICE_TYPE);
        }
        this.services.add(service);
        return String.format(ConstantMessages.SUCCESSFULLY_ADDED_SERVICE_TYPE, type);
    }

    @Override
    public String addSupplement(String type) {
        Supplement supplement = null;
        switch (type) {
            case "MetalArmor":
                supplement = new MetalArmor();
                break;
            case "PlasticArmor":
                supplement = new PlasticArmor();
                break;
            default:
                throw new IllegalArgumentException(ExceptionMessages.INVALID_SUPPLEMENT_TYPE);
        }
        this.supplements.addSupplement(supplement);
        return String.format(ConstantMessages.SUCCESSFULLY_ADDED_SUPPLEMENT_TYPE, type);
    }

    @Override
    public String supplementForService(String serviceName, String supplementType) {
        Supplement supplement = this.supplements.findFirst(supplementType);
        Service service = services.stream().filter(s -> serviceName.equals(s.getName())).findFirst().orElse(null);
        if (supplement == null || service == null) {
            throw new IllegalArgumentException(String.format(ExceptionMessages.NO_SUPPLEMENT_FOUND, supplementType));
        }
        service.addSupplement(supplement);
        this.supplements.removeSupplement(supplement);
        return String.format(ConstantMessages.SUCCESSFULLY_ADDED_SUPPLEMENT_IN_SERVICE, supplementType, serviceName);
    }

    @Override
    public String addRobot(String serviceName, String robotType, String robotName, String robotKind, double price) {
        Robot robot = null;
        Service service = services.stream().filter(s -> serviceName.equals(s.getName())).findFirst().orElse(null);
        switch (robotType) {
            case "MaleRobot":
                robot = new MaleRobot(robotName, robotKind, price);
                if (service != null && service.getClass().getSimpleName().equals("MainService")) {
                    service.addRobot(robot);
                    return String.format(ConstantMessages.SUCCESSFULLY_ADDED_ROBOT_IN_SERVICE, robotName, serviceName);
                } else if (service != null && service.getClass().getSimpleName().equals("SecondaryService")) {
                    return ConstantMessages.UNSUITABLE_SERVICE;
                }
                break;
            case "FemaleRobot":
                robot = new FemaleRobot(robotName, robotKind, price);
                if (service != null && service.getClass().getSimpleName().equals("SecondaryService")) {
                    service.addRobot(robot);
                    return String.format(ConstantMessages.SUCCESSFULLY_ADDED_ROBOT_IN_SERVICE, robotName, serviceName);
                } else if (service != null && service.getClass().getSimpleName().equals("MainService")) {
                    return ConstantMessages.UNSUITABLE_SERVICE;
                }
                break;
            default:
                throw new IllegalArgumentException(ExceptionMessages.INVALID_ROBOT_TYPE);
        }
        return null;
    }

    @Override
    public String feedingRobot(String serviceName) {
        Service service = services.stream().filter(s -> serviceName.equals(s.getName())).findFirst().orElse(null);
        if (service != null) {
            service.feeding();
            return String.format(ConstantMessages.FEEDING_ROBOT, service.getRobots().size());
        }
        return null;
    }

    @Override
    public String sumOfAll(String serviceName) {
        Service service = services.stream().filter(s -> serviceName.equals(s.getName())).findFirst().orElse(null);
        double sum = service.getRobots().stream().mapToDouble(Robot::getPrice).sum()
                + service.getSupplements().stream().mapToDouble(Supplement::getPrice).sum();
        return String.format(ConstantMessages.VALUE_SERVICE, serviceName, sum);
    }

    @Override
    public String getStatistics() {
        StringBuilder sb = new StringBuilder();
        services.forEach(e -> sb.append(e.getStatistics()));
       return sb.toString();
    }
}
