package vehicleShop.models.shop;

import vehicleShop.models.tool.Tool;
import vehicleShop.models.vehicle.Vehicle;
import vehicleShop.models.worker.Worker;

import java.util.Collection;

public class ShopImpl implements Shop {
    private Vehicle vehicle;
    private Worker worker;

    @Override
    public void make(Vehicle vehicle, Worker worker) {
        this.vehicle = vehicle;
        this.worker = worker;
        Collection<Tool> tools = worker.getTools();
        boolean hasWorkingTools = false;
        if (tools.size() > 0 && tools.stream().noneMatch(Tool::isUnfit)) {
            hasWorkingTools = true;
        }
        if (worker.getStrength() > 0 || hasWorkingTools) {
            while (!vehicle.reached() && worker.canWork()) {
                vehicle.making();
                worker.working();
                tools.stream().filter(e -> !e.isUnfit()).findFirst().orElse(null).decreasesPower();
                if (tools.size() > 0 && tools.stream().noneMatch(Tool::isUnfit)) {
                    hasWorkingTools = true;
                } else {
                    hasWorkingTools = false;
                }
            }
        }
    }
}
