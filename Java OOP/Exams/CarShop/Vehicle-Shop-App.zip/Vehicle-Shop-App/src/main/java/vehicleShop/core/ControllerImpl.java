package vehicleShop.core;

import vehicleShop.common.ConstantMessages;
import vehicleShop.common.ExceptionMessages;
import vehicleShop.models.shop.ShopImpl;
import vehicleShop.models.tool.Tool;
import vehicleShop.models.tool.ToolImpl;
import vehicleShop.models.vehicle.Vehicle;
import vehicleShop.models.vehicle.VehicleImpl;
import vehicleShop.models.worker.FirstShift;
import vehicleShop.models.worker.SecondShift;
import vehicleShop.models.worker.Worker;
import vehicleShop.repositories.VehicleRepository;
import vehicleShop.repositories.WorkerRepository;

import java.util.List;
import java.util.stream.Collectors;

public class ControllerImpl implements Controller {
    private WorkerRepository workerRepository;
    private VehicleRepository vehicleRepository;
    private int doneVehicles;

    public ControllerImpl() {
        this.workerRepository = new WorkerRepository();
        this.vehicleRepository = new VehicleRepository();
    }

    @Override
    public String addWorker(String type, String workerName) {
        Worker worker = null;
        switch (type) {
            case "FirstShift":
                worker = new FirstShift(workerName);
                break;
            case "SecondShift":
                worker = new SecondShift(workerName);
                break;
            default:
                throw new IllegalArgumentException(ExceptionMessages.WORKER_TYPE_DOESNT_EXIST);
        }
        workerRepository.add(worker);
        return String.format(ConstantMessages.ADDED_WORKER, type, workerName);
    }

    @Override
    public String addVehicle(String vehicleName, int strengthRequired) {
        Vehicle vehicle = new VehicleImpl(vehicleName, strengthRequired);
        vehicleRepository.add(vehicle);
        return String.format(ConstantMessages.SUCCESSFULLY_ADDED_VEHICLE, vehicleName);
    }

    @Override
    public String addToolToWorker(String workerName, int power) {
        Tool tool = new ToolImpl(power);
        if (!workerRepository.getWorkers().contains(workerRepository.findByName(workerName))) {
            throw new IllegalArgumentException(ExceptionMessages.HELPER_DOESNT_EXIST);
        }
        workerRepository.findByName(workerName).addTool(tool);
        return String.format(ConstantMessages.SUCCESSFULLY_ADDED_TOOL_TO_WORKER, power, workerName);
    }

    @Override
    public String makingVehicle(String vehicleName) {
        ShopImpl shop = new ShopImpl();
        long brokenTools = 0;
        List<Worker> readyWorkers = workerRepository.getWorkers()
                .stream()
                .filter(worker -> worker.getStrength() > 70)
                .collect(Collectors.toList());
        if (readyWorkers.size() < 1) {
            throw new IllegalArgumentException(ExceptionMessages.NO_WORKER_READY);
        }
        Vehicle vehicle = vehicleRepository.findByName(vehicleName);
        Worker worker = readyWorkers.stream().filter(Worker::canWork).findFirst().orElse(null);
        if (worker != null) {
            brokenTools += worker.getTools().stream().filter(Tool::isUnfit).count();
        }
        while (!vehicle.reached() && worker != null) {
            if (null != worker && worker.canWork()) {
                shop.make(vehicle, worker);
            } else {
                worker = readyWorkers.stream().filter(Worker::canWork).findFirst().orElse(null);
                if (worker != null) {
                    brokenTools += worker.getTools().stream().filter(Tool::isUnfit).count();
                }
            }
        }
        if (vehicle.reached()) {
            doneVehicles++;
            if (worker != null) {
                brokenTools += worker.getTools().stream().filter(Tool::isUnfit).count();
            }
            return String.format(ConstantMessages.VEHICLE_DONE, vehicleName, "done")
                    + String.format(ConstantMessages.COUNT_BROKEN_INSTRUMENTS, brokenTools);
        }
        return String.format(ConstantMessages.VEHICLE_DONE, vehicleName, "not done")
                + String.format(ConstantMessages.COUNT_BROKEN_INSTRUMENTS, brokenTools);
    }

    @Override
    public String statistics() {
        StringBuilder sb = new StringBuilder();
        sb.append(doneVehicles).append(" vehicles are ready!")
                .append("\n").append("Info for workers:\n");
        workerRepository.getWorkers().forEach(e -> sb.append("Name: ")
                .append(e.getName()).append(", Strength: ")
                .append(e.getStrength())
                .append("\n")
                .append("Tools: ")
                .append(e.getTools().stream().filter(tool -> !tool.isUnfit()).count()).append(" fit left\n"));
        return sb.toString().trim();
    }
}
