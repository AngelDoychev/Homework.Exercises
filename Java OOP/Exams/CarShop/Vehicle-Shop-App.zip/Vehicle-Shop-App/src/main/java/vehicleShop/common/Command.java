package vehicleShop.common;

public enum Command {
    AddWorker,
    AddVehicle,
    AddToolToWorker,
    MakingVehicle,
    Statistics,
    Exit,
}
