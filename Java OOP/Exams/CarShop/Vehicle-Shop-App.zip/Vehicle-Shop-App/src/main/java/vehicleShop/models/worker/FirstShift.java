package vehicleShop.models.worker;

import vehicleShop.models.tool.Tool;

import java.util.Collection;

public class FirstShift extends BaseWorker{
    private static final int DEFAULT_STRENGTH = 100;
    public FirstShift(String name) {
        super(name, DEFAULT_STRENGTH);
    }

    @Override
    public String getName() {
        return super.getName();
    }

    @Override
    public int getStrength() {
        return super.getStrength();
    }

    @Override
    public Collection<Tool> getTools() {
        return super.getTools();
    }
    @Override
    public void working() {
        int newStrength = super.getStrength() - 10;
        if (newStrength < 0) {
            newStrength = 0;
        }
        super.setStrength(newStrength);
    }
}
