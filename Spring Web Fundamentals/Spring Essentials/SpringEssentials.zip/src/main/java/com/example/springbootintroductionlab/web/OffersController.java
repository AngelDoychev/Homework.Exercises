package com.example.springbootintroductionlab.web;

import com.example.springbootintroductionlab.service.OfferService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/offers")
public class OffersController {
private final OfferService offerService;

    public OffersController(OfferService offerService) {
        this.offerService = offerService;
    }
    @GetMapping("/all")
    public String getAllOffers(Model model){
        model.addAttribute(this.offerService.getAllOffers());
        return "offers";
    }
    @GetMapping("/add")
    public String addOffer(){
        return "offer-add";
    }
}
