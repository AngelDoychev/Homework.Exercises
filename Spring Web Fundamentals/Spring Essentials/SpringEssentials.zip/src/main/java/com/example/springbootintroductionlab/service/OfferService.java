package com.example.springbootintroductionlab.service;

import com.example.springbootintroductionlab.model.entities.Offer;

import java.util.List;

public interface OfferService {
    List<Offer> getAllOffers();
}
