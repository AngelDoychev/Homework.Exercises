package com.example.springbootintroductionlab.model.entities.enums;

public enum RoleEnum {
    User,
    Admin
}
