package com.example.springbootintroductionlab.model.view;

import java.util.ArrayList;
import java.util.List;

public class BrandView {
    private String name;

    List<ModelView> models = new ArrayList<>();

    public BrandView() {
    }
    public BrandView addModel(ModelView modelView){
        this.models.add(modelView);
        return this;
    }

    public List<ModelView> getModels() {
        return models;
    }

    public void setModels(List<ModelView> models) {
        this.models = models;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
