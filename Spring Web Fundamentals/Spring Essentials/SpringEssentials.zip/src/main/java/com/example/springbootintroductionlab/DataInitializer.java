package com.example.springbootintroductionlab;

import com.example.springbootintroductionlab.model.entities.Brand;
import com.example.springbootintroductionlab.model.entities.Model;
import com.example.springbootintroductionlab.model.entities.User;
import com.example.springbootintroductionlab.model.entities.UserRole;
import com.example.springbootintroductionlab.model.entities.enums.CategoryEnum;
import com.example.springbootintroductionlab.model.entities.enums.RoleEnum;
import com.example.springbootintroductionlab.repository.BrandRepository;
import com.example.springbootintroductionlab.repository.ModelRepository;
import com.example.springbootintroductionlab.repository.UserRepository;
import com.example.springbootintroductionlab.repository.UserRoleRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.List;
import java.util.Objects;

@Component
public class DataInitializer implements CommandLineRunner {
    private final BrandRepository brandRepository;
    private final ModelRepository modelRepository;
    private final UserRepository userRepository;
    private final UserRoleRepository userRoleRepository;
    private final PasswordEncoder passwordEncoder;

    public DataInitializer(BrandRepository brandRepository, ModelRepository modelRepository, UserRepository userRepository, UserRoleRepository userRoleRepository, PasswordEncoder passwordEncoder) {
        this.brandRepository = brandRepository;
        this.modelRepository = modelRepository;
        this.userRepository = userRepository;
        this.userRoleRepository = userRoleRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) throws Exception {
        if (this.modelRepository.count() == 0) {
            Brand mercedes = new Brand();
            mercedes.setName("mercedes");
            Brand bmw = new Brand();
            bmw.setName("bmw");
            bmw.setCreated(Instant.now());
            bmw.setModified(Instant.now());
            mercedes.setCreated(Instant.now());
            mercedes.setModified(Instant.now());
            Model c = new Model();
            Model e = new Model();
            Model model330 = new Model();
            Model model530 = new Model();
            c.setBrand(mercedes);
            c.setCategory(CategoryEnum.Car);
            c.setName("C-Class");
            c.setStartYear(1999);
            c.setImageUrl("https://www.autocar.co.uk/sites/autocar.co.uk/files/mercedes-c-class_0.jpg");
            c.setCreated(Instant.now());
            c.setModified(Instant.now());
            e.setBrand(mercedes);
            e.setName("E-Class");
            e.setCategory(CategoryEnum.Car);
            e.setStartYear(1999);
            e.setCreated(Instant.now());
            e.setModified(Instant.now());
            e.setImageUrl("https://assets-eu-01.kc-usercontent.com/3b3d460e-c5ae-0195-6b86-3ac7fb9d52db/f14d9e80-3cfb-4bb2-962e-fba507343223/Mercedes%20E-Class%202022%20front%20driving.jpg?fm=jpg&auto=format");
            model330.setBrand(bmw);
            model330.setStartYear(1999);
            model330.setName("3-series");
            model330.setCategory(CategoryEnum.Car);
            model330.setImageUrl("https://hips.hearstapps.com/hmg-prod/images/2023-bmw-m340i-xdrive-350-640f4198a073d.jpg?crop=0.667xw:0.748xh;0.212xw,0.252xh&resize=768:*");
            model330.setCreated(Instant.now());
            model330.setModified(Instant.now());
            model530.setBrand(bmw);
            model530.setStartYear(1999);
            model530.setName("5-series");
            model530.setCategory(CategoryEnum.Car);
            model530.setImageUrl("https://www.motortrend.com/uploads/2023/05/2024-bmw-5-series-17.jpeg?fit=around%7C875:492");
            model530.setCreated(Instant.now());
            model530.setModified(Instant.now());
            this.brandRepository.save(mercedes);
            this.brandRepository.save(bmw);
            this.modelRepository.save(c);
            this.modelRepository.save(e);
            this.modelRepository.save(model330);
            this.modelRepository.save(model530);
            UserRole adminRole = new UserRole();
            UserRole userRole = new UserRole();
            adminRole.setRole(RoleEnum.Admin);
            userRole.setRole(RoleEnum.User);
            this.userRoleRepository.saveAll(List.of(adminRole, userRole));
            User admin = new User();
            admin.setCreated(Instant.now());
            admin.setModified(Instant.now());
            admin.setRoles(List.of(Objects.requireNonNull(this.userRoleRepository.findById(1L).orElse(null))));
            admin.setUsername("admin");
            admin.setPassword(this.passwordEncoder.encode("secret"));
            User user = new User();
            user.setCreated(Instant.now());
            user.setModified(Instant.now());
            user.setRoles(List.of(Objects.requireNonNull(this.userRoleRepository.findById(2L).orElse(null))));
            user.setUsername("user");
            user.setPassword(this.passwordEncoder.encode("secret"));
            this.userRepository.saveAll(List.of(admin, user));
        }
    }
}
