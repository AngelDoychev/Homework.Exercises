package com.example.springbootintroductionlab.service;

public interface UserService {
    boolean authenticate(String username, String password);
    void loginUser(String username);

    void logoutUser();
}
