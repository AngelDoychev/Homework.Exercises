package com.example.springbootintroductionlab.model.entities.enums;

public enum TransmissionEnum {
    MANUAL,
    AUTOMATIC
}
