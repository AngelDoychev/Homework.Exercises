package com.example.springbootintroductionlab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootIntroductionLabApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootIntroductionLabApplication.class, args);
	}

}
