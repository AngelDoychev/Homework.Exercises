package com.example.springbootintroductionlab.service.impl;

import com.example.springbootintroductionlab.repository.UserRepository;
import com.example.springbootintroductionlab.service.UserService;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {
    private final UserRepository userRepository;

    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
}
