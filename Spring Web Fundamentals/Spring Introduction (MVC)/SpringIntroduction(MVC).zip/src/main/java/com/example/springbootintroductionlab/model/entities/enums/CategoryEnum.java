package com.example.springbootintroductionlab.model.entities.enums;

public enum CategoryEnum {
    Car,
    Buss,
    Truck,
    Motorcycle
}
