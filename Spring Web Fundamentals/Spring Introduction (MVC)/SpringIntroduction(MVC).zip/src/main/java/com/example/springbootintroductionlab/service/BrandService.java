package com.example.springbootintroductionlab.service;

import com.example.springbootintroductionlab.model.view.BrandView;


import java.util.List;

public interface BrandService {
    List<BrandView> getAllBrands();
}
