package com.example.springbootintroductionlab.service.impl;

import com.example.springbootintroductionlab.model.entities.Brand;
import com.example.springbootintroductionlab.model.entities.Model;
import com.example.springbootintroductionlab.model.view.BrandView;
import com.example.springbootintroductionlab.model.view.ModelView;
import com.example.springbootintroductionlab.repository.BrandRepository;
import com.example.springbootintroductionlab.repository.ModelRepository;
import com.example.springbootintroductionlab.service.BrandService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class BrandServiceImpl implements BrandService {
    private final BrandRepository brandRepository;
    private final ModelRepository modelRepository;
    private final ModelMapper modelMapper;

    public BrandServiceImpl(BrandRepository brandRepository, ModelRepository modelRepository, ModelMapper modelMapper) {
        this.brandRepository = brandRepository;
        this.modelRepository = modelRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public List<BrandView> getAllBrands() {
        List<BrandView> brandView = new ArrayList<>();
        List<Model> allModels = this.modelRepository.findAll();
        allModels.forEach(model -> {
            Brand brand = model.getBrand();
            Optional<BrandView> brandViewOptional = findByName(brandView, brand.getName());
            if (!brandViewOptional.isPresent()){
                BrandView newBrandView = new BrandView();
                this.modelMapper.map(brand, newBrandView);
                brandView.add(newBrandView);
                brandViewOptional = Optional.of(newBrandView);
            }
            ModelView modelView = new ModelView();
            modelMapper.map(model, modelView);
            brandViewOptional.get().addModel(modelView);
        });
        return brandView;
    }
    private static Optional<BrandView> findByName(List<BrandView> brands, String name){
        return brands.stream().filter(e -> e.getName().equals(name)).findAny();
    }
}
