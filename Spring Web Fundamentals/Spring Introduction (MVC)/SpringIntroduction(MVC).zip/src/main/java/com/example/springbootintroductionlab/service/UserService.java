package com.example.springbootintroductionlab.service;

public interface UserService {
}
