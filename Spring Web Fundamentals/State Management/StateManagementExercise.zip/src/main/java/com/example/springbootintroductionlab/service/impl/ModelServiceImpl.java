package com.example.springbootintroductionlab.service.impl;

import com.example.springbootintroductionlab.repository.ModelRepository;
import com.example.springbootintroductionlab.service.ModelService;
import org.springframework.stereotype.Service;

@Service
public class ModelServiceImpl implements ModelService {
    private final ModelRepository modelRepository;

    public ModelServiceImpl(ModelRepository modelRepository) {
        this.modelRepository = modelRepository;
    }
}
