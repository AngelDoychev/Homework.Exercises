package com.example.springbootintroductionlab.model.view;

import com.example.springbootintroductionlab.model.entities.Brand;
import com.example.springbootintroductionlab.model.entities.enums.CategoryEnum;

public class ModelView {
    private String name;
    private CategoryEnum category;
    private String imageUrl;
    private int startYear;
    private Integer endYear;
    private Brand brand;

    public ModelView() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public CategoryEnum getCategory() {
        return category;
    }

    public void setCategory(CategoryEnum category) {
        this.category = category;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public int getStartYear() {
        return startYear;
    }

    public void setStartYear(int startYear) {
        this.startYear = startYear;
    }

    public Integer getEndYear() {
        return endYear;
    }

    public void setEndYear(Integer endYear) {
        this.endYear = endYear;
    }

    public Brand getBrand() {
        return brand;
    }

    public void setBrand(Brand brand) {
        this.brand = brand;
    }
}
