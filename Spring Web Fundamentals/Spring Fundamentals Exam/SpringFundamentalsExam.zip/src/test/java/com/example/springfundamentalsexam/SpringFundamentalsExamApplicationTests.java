package com.example.springfundamentalsexam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringFundamentalsExamApplicationTests {

    @Test
    void contextLoads() {
    }

}
