package com.example.springfundamentalsexam;

import com.example.springfundamentalsexam.model.Category;
import com.example.springfundamentalsexam.model.enums.CategoryNameEnum;
import com.example.springfundamentalsexam.repository.CategoryRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class CommandLineRunnerImpl implements CommandLineRunner {
    private final CategoryRepository categoryRepository;

    public CommandLineRunnerImpl(CategoryRepository categoryRepository) {
        this.categoryRepository = categoryRepository;
    }

    @Override
    public void run(String... args) throws Exception {
        if (this.categoryRepository.count() == 0){
            initCategories();
        }

    }

    private void initCategories() {
        Category foodCategory = new Category();
        foodCategory.setName(CategoryNameEnum.Food);
        String foodDescription = "Something you can digest and chew.";
        foodCategory.setDescription(foodDescription);

        Category drinkCategory = new Category();
        drinkCategory.setName(CategoryNameEnum.Drink);
        String drinkDescription = "Something you can digest and drink.";
        drinkCategory.setDescription(drinkDescription);

        Category householdCategory = new Category();
        householdCategory.setName(CategoryNameEnum.Household);
        String householdDescription = "Something you can use and put in your house.";
        householdCategory.setDescription(householdDescription);

        Category otherCategory = new Category();
        otherCategory.setName(CategoryNameEnum.Other);
        String otherDescription = "Everything else  that is not food, a drink or a household item.";
        otherCategory.setDescription(otherDescription);

        this.categoryRepository.saveAll(List.of(foodCategory, drinkCategory, householdCategory, otherCategory));
    }
}
