package com.example.springfundamentalsexam.service.Impl;

import com.example.springfundamentalsexam.model.User;
import com.example.springfundamentalsexam.repository.UserRepository;
import com.example.springfundamentalsexam.security.CurrentUser;
import com.example.springfundamentalsexam.service.UserService;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {
    private final UserRepository userRepository;
    private final CurrentUser currentUser;

    public UserServiceImpl(UserRepository userRepository, CurrentUser currentUser) {
        this.userRepository = userRepository;
        this.currentUser = currentUser;
    }

    @Override
    public boolean authenticate(String username, String password) {
        return this.userRepository.findUserByUsernameAndPassword(username, password).isPresent();
    }

    @Override
    public void loginUser(String username) {
        this.currentUser.setAnonymous(false);
        this.currentUser.setUsername(username);
    }

    @Override
    public void saveUser(User user) {
        this.userRepository.save(user);
    }
}
