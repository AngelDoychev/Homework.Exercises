package com.example.springfundamentalsexam.service.Impl;

import com.example.springfundamentalsexam.model.Category;
import com.example.springfundamentalsexam.model.enums.CategoryNameEnum;
import com.example.springfundamentalsexam.repository.CategoryRepository;
import com.example.springfundamentalsexam.service.CategoryService;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class CategoryServiceImpl implements CategoryService {
    private final CategoryRepository categoryRepository;

    public CategoryServiceImpl(CategoryRepository categoryRepository) {
        this.categoryRepository = categoryRepository;
    }

    @Override
    public Optional<Category> findByName(CategoryNameEnum name) {
        return this.categoryRepository.findFirstByName(name);
    }
}
