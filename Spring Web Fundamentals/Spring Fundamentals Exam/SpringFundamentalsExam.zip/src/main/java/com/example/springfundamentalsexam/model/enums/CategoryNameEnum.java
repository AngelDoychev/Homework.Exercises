package com.example.springfundamentalsexam.model.enums;

public enum CategoryNameEnum {
    Food,
    Drink,
    Household,
    Other
}
