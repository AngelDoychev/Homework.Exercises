package com.example.springfundamentalsexam.web;

import com.example.springfundamentalsexam.model.service.LoginServiceModel;
import com.example.springfundamentalsexam.security.CurrentUser;
import com.example.springfundamentalsexam.service.UserService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class LoginController {
    private final UserService userService;
    private final CurrentUser currentUser;

    public LoginController(UserService userService, CurrentUser currentUser) {
        this.userService = userService;
        this.currentUser = currentUser;
    }

    @GetMapping("/login")
    private String login(Model model) {
        if (!this.currentUser.isAnonymous()) {
            return "redirect:/home";
        } else {
            if (!model.containsAttribute("loginServiceModel")) {
                model.addAttribute("loginServiceModel", new LoginServiceModel());
                model.addAttribute("notFound", false);
            }
            return "login";
        }
    }

    @PostMapping("/login")
    private String onLogin(@Valid @ModelAttribute LoginServiceModel loginServiceModel,
                           BindingResult bindingResult, RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("loginServiceModel", loginServiceModel);
            redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.loginServiceModel", bindingResult);
            return "redirect:/login";
        }
        if (this.userService.authenticate(loginServiceModel.getUsername(), loginServiceModel.getPassword())) {
            this.userService.loginUser(loginServiceModel.getUsername());
            return "redirect:/home";
        } else {
            redirectAttributes.addFlashAttribute("loginServiceModel", loginServiceModel);
            redirectAttributes.addFlashAttribute("notFound", true);
            return "redirect:/login";
        }
    }

    @GetMapping("/logout")
    private String logout() {
        if (this.currentUser.isAnonymous()) {
            return "redirect:/login";
        } else {
            this.currentUser.setAnonymous(true);
            return "redirect:/";
        }
    }
}
