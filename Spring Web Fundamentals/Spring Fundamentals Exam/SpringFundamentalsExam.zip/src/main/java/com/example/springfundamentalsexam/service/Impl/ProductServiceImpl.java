package com.example.springfundamentalsexam.service.Impl;

import com.example.springfundamentalsexam.model.Product;
import com.example.springfundamentalsexam.repository.ProductRepository;
import com.example.springfundamentalsexam.service.ProductService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductServiceImpl implements ProductService {
private final ProductRepository productRepository;

    public ProductServiceImpl(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    @Override
    public void saveProduct(Product product) {
        this.productRepository.save(product);
    }

    @Override
    public List<Product> findAll() {
        return this.productRepository.findAll();
    }

    @Override
    public Optional<Product> findById(Long id) {
        return this.productRepository.findById(id);
    }

    @Override
    public void deleteProduct(Product product) {
        this.productRepository.delete(product);
    }

    @Override
    public void deleteAllProducts() {
        this.productRepository.deleteAll(this.productRepository.findAll());
    }
}
