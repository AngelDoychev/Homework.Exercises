package com.example.springfundamentalsexam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringFundamentalsExamApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringFundamentalsExamApplication.class, args);
    }

}
