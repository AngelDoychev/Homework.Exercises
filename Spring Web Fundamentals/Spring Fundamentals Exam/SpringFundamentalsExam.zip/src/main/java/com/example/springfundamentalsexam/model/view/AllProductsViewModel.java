package com.example.springfundamentalsexam.model.view;

import java.util.ArrayList;
import java.util.List;

public class AllProductsViewModel {
    private List<ProductViewModel> products = new ArrayList<>();

    public AllProductsViewModel() {
    }

    public List<ProductViewModel> getProducts() {
        return products;
    }

    public void setProducts(List<ProductViewModel> products) {
        this.products = products;
    }
}
