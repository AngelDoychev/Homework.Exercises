package com.example.springfundamentalsexam.service;

import com.example.springfundamentalsexam.model.Product;

import java.util.List;
import java.util.Optional;

public interface ProductService {
    void saveProduct(Product product);
    List<Product> findAll();

    Optional<Product> findById(Long id);

    void deleteProduct(Product product);

    void deleteAllProducts();
}
