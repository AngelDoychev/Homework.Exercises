package com.example.springfundamentalsexam.service;

import com.example.springfundamentalsexam.model.Category;
import com.example.springfundamentalsexam.model.enums.CategoryNameEnum;

import java.util.Optional;

public interface CategoryService {
    Optional<Category> findByName(CategoryNameEnum name);
}
