package com.example.springfundamentalsexam.web;

import com.example.springfundamentalsexam.model.User;
import com.example.springfundamentalsexam.model.service.RegisterServiceModel;
import com.example.springfundamentalsexam.security.CurrentUser;
import com.example.springfundamentalsexam.service.UserService;
import jakarta.validation.Valid;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class RegisterController {
    private final UserService userService;
    private final ModelMapper modelMapper;
    private final CurrentUser currentUser;

    public RegisterController(UserService userService, ModelMapper modelMapper, CurrentUser currentUser) {
        this.userService = userService;
        this.modelMapper = modelMapper;
        this.currentUser = currentUser;
    }

    @GetMapping("/register")
    private String register(Model model) {
        if (!this.currentUser.isAnonymous()) {
            return "redirect:/home";
        } else {
            if (!model.containsAttribute("registerServiceModel")) {
                model.addAttribute("registerServiceModel", new RegisterServiceModel());
            }
            return "register";
        }
    }

    @PostMapping("/register")
    private String onRegister(@Valid @ModelAttribute RegisterServiceModel registerServiceModel,
                              BindingResult bindingResult, RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors() || !registerServiceModel.getPassword().equals(registerServiceModel.getConfirmPassword())) {
            redirectAttributes.addFlashAttribute("registerServiceModel", registerServiceModel);
            redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.registerServiceModel", bindingResult);
            return "redirect:/register";
        }
        User user = this.modelMapper.map(registerServiceModel, User.class);
        this.userService.saveUser(user);
        return "redirect:/login";
    }
}
