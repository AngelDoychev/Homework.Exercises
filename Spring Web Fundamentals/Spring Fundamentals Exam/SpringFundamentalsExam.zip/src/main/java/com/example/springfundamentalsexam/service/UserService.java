package com.example.springfundamentalsexam.service;

import com.example.springfundamentalsexam.model.User;

public interface UserService {
    boolean authenticate(String username, String password);

    void loginUser(String username);

     void saveUser(User user);
}
