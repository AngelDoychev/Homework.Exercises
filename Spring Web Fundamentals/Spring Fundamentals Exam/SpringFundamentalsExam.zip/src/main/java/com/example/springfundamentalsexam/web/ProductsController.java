package com.example.springfundamentalsexam.web;

import com.example.springfundamentalsexam.model.Product;
import com.example.springfundamentalsexam.model.enums.CategoryNameEnum;
import com.example.springfundamentalsexam.model.service.AddProductServiceModel;
import com.example.springfundamentalsexam.security.CurrentUser;
import com.example.springfundamentalsexam.service.CategoryService;
import com.example.springfundamentalsexam.service.ProductService;
import jakarta.validation.Valid;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class ProductsController {
    private final ProductService productService;
    private final ModelMapper modelMapper;
    private final CategoryService categoryService;
    private final CurrentUser currentUser;

    public ProductsController(ProductService productService, ModelMapper modelMapper, CategoryService categoryService, CurrentUser currentUser) {
        this.productService = productService;
        this.modelMapper = modelMapper;
        this.categoryService = categoryService;
        this.currentUser = currentUser;
    }

    @GetMapping("/product-add")
    private String addProduct(Model model) {
        if (this.currentUser.isAnonymous()){
            return "redirect:/login";
        } else {
            if (!model.containsAttribute("addProductServiceModel")) {
                model.addAttribute("addProductServiceModel", new AddProductServiceModel());
            }
            return "product-add";
        }
    }

    @PostMapping("/product-add")
    private String onAddProduct(@Valid @ModelAttribute AddProductServiceModel addProductServiceModel,
                                BindingResult bindingResult, RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("addProductServiceModel", addProductServiceModel);
            redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.addProductServiceModel", bindingResult);
            return "redirect:/product-add";
        }
        String categoryName = addProductServiceModel.getCategory().toLowerCase();
        categoryName = categoryName.substring(0,1).toUpperCase() + categoryName.substring(1).toLowerCase();
        CategoryNameEnum category = CategoryNameEnum.valueOf(categoryName);
        Product product = this.modelMapper.map(addProductServiceModel, Product.class);
        product.setCategory(this.categoryService.findByName(category).get());
        this.productService.saveProduct(product);
        return "redirect:/home";
    }
}
