package com.example.springfundamentalsexam.web;

import com.example.springfundamentalsexam.model.Product;
import com.example.springfundamentalsexam.model.enums.CategoryNameEnum;
import com.example.springfundamentalsexam.security.CurrentUser;
import com.example.springfundamentalsexam.service.CategoryService;
import com.example.springfundamentalsexam.service.ProductService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.math.BigDecimal;
import java.util.List;

@Controller
public class HomeController {
    private final ProductService productService;
    private final CategoryService categoryService;
    private final CurrentUser currentUser;

    public HomeController(ProductService productService, CategoryService categoryService, CurrentUser currentUser) {
        this.productService = productService;
        this.categoryService = categoryService;
        this.currentUser = currentUser;
    }

    @GetMapping("/")
    private String index(){
        if (this.currentUser.isAnonymous()){
            return "index";
        }
        return "redirect:/home";
    }
    @GetMapping("/home")
    private String home(Model model){
        if (this.currentUser.isAnonymous()){
            return "redirect:/login";
        } else {
            List<Product> foodList = makeListFromCategoryName("Food");
            model.addAttribute("foodList", foodList);
            List<Product> drinkList = makeListFromCategoryName("Drink");
            model.addAttribute("drinkList", drinkList);
            List<Product> householdList = makeListFromCategoryName("Household");
            model.addAttribute("householdList", householdList);
            List<Product> otherList = makeListFromCategoryName("Other");
            model.addAttribute("otherList", otherList);
            BigDecimal sumPrice = this.productService.findAll().stream().map(Product::getPrice).reduce(BigDecimal.ZERO, BigDecimal::add);
            model.addAttribute("sumPrice", sumPrice);
            return "home";
        }
    }
    @GetMapping(value = "/deleteProduct/{productId}")
    public String deleteProduct(@PathVariable String productId) {
        Product product = this.productService.findById(Long.parseLong(productId)).get();
        this.productService.deleteProduct(product);
        return "redirect:/home";
    }
    @GetMapping(value = "/deleteAllProducts")
    public String deleteAllProducts() {
        this.productService.deleteAllProducts();
        return "redirect:/home";
    }

    private List<Product> makeListFromCategoryName(String category) {
        return this.productService.findAll().stream()
                .filter(product -> product.getCategory().equals(this.categoryService
                        .findByName(CategoryNameEnum.valueOf(category))
                        .get()))
                .toList();
    }
}
