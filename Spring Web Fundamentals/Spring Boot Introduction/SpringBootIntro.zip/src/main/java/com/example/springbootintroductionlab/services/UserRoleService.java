package com.example.springbootintroductionlab.services;

public interface UserRoleService {
}
