package com.example.springbootintroductionlab.services.impl;

import com.example.springbootintroductionlab.repositories.BrandRepository;
import com.example.springbootintroductionlab.services.BrandService;
import org.springframework.stereotype.Service;

@Service
public class BrandServiceImpl implements BrandService {
    private final BrandRepository brandRepository;

    public BrandServiceImpl(BrandRepository brandRepository) {
        this.brandRepository = brandRepository;
    }
}
