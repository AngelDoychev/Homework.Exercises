package com.example.springbootintroductionlab.services;

public interface ModelService {
}
