package com.example.springbootintroductionlab.services.impl;

import com.example.springbootintroductionlab.repositories.UserRoleRepository;
import com.example.springbootintroductionlab.services.UserRoleService;
import org.springframework.stereotype.Service;

@Service
public class UserRoleServiceImpl implements UserRoleService {
    private final UserRoleRepository userRoleRepository;

    public UserRoleServiceImpl(UserRoleRepository userRoleRepository) {
        this.userRoleRepository = userRoleRepository;
    }
}
