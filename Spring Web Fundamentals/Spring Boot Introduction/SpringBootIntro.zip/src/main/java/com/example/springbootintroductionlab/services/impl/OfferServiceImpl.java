package com.example.springbootintroductionlab.services.impl;

import com.example.springbootintroductionlab.repositories.OfferRepository;
import com.example.springbootintroductionlab.services.OfferService;
import org.springframework.stereotype.Service;

@Service
public class OfferServiceImpl implements OfferService {
    private final OfferRepository offerRepository;

    public OfferServiceImpl(OfferRepository offerRepository) {
        this.offerRepository = offerRepository;
    }
}
