package com.example.springbootintroductionlab.model.entities.enums;

public enum EngineEnum {
    GASOLINE,
    DIESEL,
    ELECTRIC,
    HYBRID
}
