package com.example.springbootintroductionlab.services;

public interface BrandService {
}
